"use client";
import React, { useState, useEffect } from "react";
import styled from "styled-components";
import { Text, Dropdown, Grid, User, Button } from "@nextui-org/react";
import { signIn, signOut } from "next-auth/react";
import { useSession } from "next-auth/react";
import { useRouter, usePathname } from "next/navigation";
import { createAccessToken } from "@/apis/userApis";
import { deleteCookie, getCookie, setCookie } from "@/utils/cookieUtil";
import { useIsMobile, useIsTablet } from "@/hooks/useMediaQuery";
import Routes from "../../../routes";
import LoginModal from "../LoginModal/LoginModal";
import { CONSTS } from "@/constants";
import { IconMenu2 } from "@tabler/icons";
import Link from "next/link";
const HeaderDiv = styled.div<{ isMobile: boolean; isTablet: boolean }>`
  height: 62px;
  flex-shrink: 0;
  border-bottom: 1px solid var(--correct-stroke, #eeeeef);
  background: rgba(255, 255, 255, 0.4);
  display: flex;
  justify-content: space-between;
  margin-left: 10px;
  padding: ${(props) =>
    props.isMobile ? "5px 5px" : props.isTablet ? "5px 25px" : "5px 50px"};
`;
const LogoDiv = styled.div`
  display: inline-flex;
  align-items: center;
  gap: 6px;
  cursor: pointer;
`;
const CarouselDiv = styled.div<{ visible: boolean }>`
  display: flex;
  width: 100%;
  align-items: flex-start;
  justify-content: center;
  height: ${(props) => (props.visible ? "385px" : "0")};
  overflow: hidden;
  transition: height 0.3s ease-in-out;
  @media only screen and (max-width: 1024px) {
    width: 950px;
  }
`;
const CarouselRow = styled.div`
  display: flex;
  width: 100%;
  padding: 10px 10px 10px 10px;
  overflow-x: scroll;
`;
const SigninButton = styled.button`
  display: inline-flex;
  padding: 6px 14px;
  justify-content: center;
  align-items: center;
  gap: 10px;
  border-radius: 10px;
  border: 1px solid ${CONSTS.BRAND_COLORS.PRIMARY};
  color: ${CONSTS.BRAND_COLORS.PRIMARY};
  background: ${CONSTS.BRAND_COLORS.WHITE};
  font-size: 16px;

  font-weight: 500;
  line-height: normal;
  cursor: pointer;
`;

const Wrapper = styled(Grid)`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 9px;
  border: 0.6px solid var(--bobo, #cdd5e1);
  border-radius: 50px;
  padding: 2px;
`;
const dropDownStyle = {
  color: "#475467",
  "&:hover": {
    background: "#ffffff",
  },
};
const CustomUserDropdown = styled(User)`
  cursor: pointer;
`;

const HeaderLinks = styled.div`
  display: flex;
  align-items: center;
  gap: 4vw;

  @media only screen and (max-width: 1024px) {
    gap: 1vw;
  }
  @media only screen and (max-width: 768px) {
    display: none;
  }
`;
const HeaderWrapperLinks = styled.div`
  display: flex;
  align-items: center;
  gap: 20px;

  @media only screen and (max-width: 768px) {
    display: none;
  }
`;
const TabletWrapperLinks = styled.div`
  align-items: center;
  display: none;

  @media only screen and (max-width: 768px) {
    display: flex;
  }
`;
const SlideoutMenu = styled.div<{menuVisible:boolean}>`
  display: none;
  position: fixed;
  
  right: ${(props) => (props.menuVisible ? "0" : "-300px")};
  width: 170px;
  height: 105%;
  background-color:white;
  background: #FFF;
box-shadow: 0px 24px 50px -12px rgba(45, 54, 67, 0.12);
transition: right 1s ease-in-out;
  z-index: 100;
  padding: 24px 34px 119px 34px;
flex-direction: column;
  /* Add additional styling as needed */

  @media only screen and (max-width: 768px) {
    display: flex;
  }
`;
const Header = () => {
  const [carouselVisible, setCarouselVisible] = useState(false);
  const [chevronRotation, setChevronRotation] = useState(0);
  const { data: session } = useSession();
  const pathname = usePathname();
  const router = useRouter();
  const isMobile = useIsMobile();
  const isTablet = useIsTablet();
  const accessToken = getCookie("accessToken");

  const [visible, setVisible] = React.useState(false);
  const [menuVisible, setMenuVisible] = useState(false);
  const handleDropDown = () => {
    setCarouselVisible(!carouselVisible);
    setChevronRotation(chevronRotation === 0 ? 180 : 0);
  };
  const closeHandler = () => {
    setVisible(false);
    console.log("closed");
  };
  const toggleMenu = () => {
    setMenuVisible(!menuVisible);
  };
  const handleItemClick = (itemKey: React.Key) => {
    if (itemKey === "billing") {
      router.push(Routes.billings.path);
    } else if (itemKey === "logout") {
      handleSignOut();
    } else if (itemKey === "manage") {
      //@ts-ignore
      router.push(Routes.dashboard.path);
    } else if (itemKey === "examples") {
      handleDropDown();
    } else if (itemKey === "how") {
      router.push(Routes.howItWorks.path);
    }
  };

  const handler = () => setVisible(true);

  // const handleSignIn = (provider: string) => {
  //   signIn(provider, { callbackUrl: "/" });
  // };

  const handleSignOut = () => {
    deleteCookie("accessToken");
    console.log("cookie deleted");
    signOut({ callbackUrl: "/" });
  };

  useEffect(() => {
    const fetchData = async () => {
      const accessToken = getCookie("accessToken");
      const sessionId = getCookie("sessionId");
      if (pathname === "/" && session && !accessToken) {
        const body = {
          iss: "https://accounts.google.com",
          azp: process.env.NEXT_CLIENT_ID,
          aud: process.env.NEXT_CLIENT_ID,
          email: session.user?.email,
          email_verified: true,
          name: session.user?.name,
          picture: session.user?.image,
          sessionId: sessionId,
          identity: "google",
          ref: "/",
          role: "consumer",
          context: "app",
        };

        console.log("calling api");
        const loginData: any = await createAccessToken(body);

        const accessToken = loginData?.result?.accessToken?.id;

        setCookie("accessToken", accessToken);
        console.log("login token created");
      }
    };

    fetchData();
  }, [pathname, session]);

  const isPathname = pathname === "/" || pathname.includes("edit");

  return (
    <>
      <HeaderDiv isMobile={isMobile} isTablet={isTablet} style={{}}>
        <LogoDiv onClick={() => router.push("/")}>
          <img
            src={CONSTS.LOGO_PATH}
            alt=""
            height={isMobile ? "20vh" : "30vh"}
          />
        </LogoDiv>
        <HeaderLinks>
          <Text>Projects</Text>
          <Text>Pricing</Text>
          <Text>Affiliate</Text>
          
          <Link style={{textDecoration:"none"}} href="https://aicaptions.canny.io/feature-requests/">
              <Text size={16}>Community</Text>
              </Link>
          <Text>Creators</Text>
        </HeaderLinks>
        <HeaderWrapperLinks>
          {!session ? (
            <SigninButton onClick={handler}>Sign In</SigninButton>
          ) : (
            <Dropdown placement="bottom-left">
              <Dropdown.Trigger>
                <Wrapper>
                  <CustomUserDropdown
                    size="sm"
                    color="success"
                    className="customUserDropdown"
                    name={session?.user?.name}
                    src={session?.user?.image ?? undefined}
                    css={{ m: "0px", p: "0px" }}
                  />
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="icon icon-tabler icon-tabler-chevron-down"
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    strokeWidth="1.5"
                    stroke="#000000"
                    fill="none"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                    <path d="M6 9l6 6l6 -6" />
                  </svg>
                </Wrapper>
              </Dropdown.Trigger>
              <Dropdown.Menu
                onAction={handleItemClick}
                aria-label="user-actions"
              >
                <Dropdown.Item key="billing" css={dropDownStyle}>
                  Billings
                </Dropdown.Item>
                <Dropdown.Item key="how" css={dropDownStyle}>
                  How it works
                </Dropdown.Item>
                <Dropdown.Item key="logout" color="error">
                  Logout
                </Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          )}
        </HeaderWrapperLinks>

        <TabletWrapperLinks>
          <IconMenu2 style={{ marginRight: "20px",cursor:"pointer" }} onClick={toggleMenu}/>
         
        </TabletWrapperLinks>
      </HeaderDiv>
      {menuVisible && (
            <SlideoutMenu menuVisible={menuVisible}>
             <div style={{display:"flex",flexDirection:"column",gap:"50px"}}>
              <div style={{display:"flex",alignItems:"center",justifyContent:"center"}}>
              <CustomUserDropdown
                    size="md"
                    bordered
                    color="success"
                    className="customUserDropdown"
                    name={""}
                    src={session?.user?.image ?? undefined}
                    css={{ m: "0px", p: "0px",w:"100px" }}
                  />
               <Text size={16} weight={"normal"}>{session?.user?.name ? `${session.user.name.charAt(0).toUpperCase()}${session.user.name.slice(1).toLowerCase()}` : ''}</Text>   
              </div>
              <Text size={16}>Projects</Text>
              <Text size={16}>Pricing</Text>

              <Text size={16}>Affiliate</Text>
              <Link href="https://aicaptions.canny.io/feature-requests/">
              <Text size={16}>Community</Text>
              </Link>
              
              <Text size={16}>Creators</Text>
             </div>
              </SlideoutMenu>
          )}
      <LoginModal visible={visible} setVisible={setVisible} />
      {!accessToken && !session && pathname === "/" && (
        <div
          onClick={handleDropDown}
          style={{
            padding: isMobile ? "10px" : "20px",
            boxSizing: "border-box",
            //@ts-ignore
            backgroundColor: CONSTS.BRAND_COLORS.PRIMART50,
            width: "100%",
            fontSize: "14px",
            margin: "0px",
            fontWeight: "500",
            display: "block",
          }}
        >
          <Text
            css={{
              textAlign: "center",
              boxSizing: "border-box",
              fontSize: isMobile ? "15x" : "24px",
              fontWeight: "700",
            }}
          >
            Micro Saas Template!
          </Text>
          <Button
            onPress={() => router.push(Routes.howItWorks.path)}
            light
            css={{ m: "auto", mt: "20px", color: CONSTS.BRAND_COLORS.PRIMARY }}
          >
            See How it works
          </Button>
        </div>
      )}
    </>
  );
};

export default Header;
