import { Text } from '@nextui-org/react';
import React from 'react';

const HighlightColor = ({color,label}:any) => {
    const handleChange=(e:any)=>{}
    return (
        <div style={{ position: 'relative' }}>
         <Text css={{fontSize:'14px',pl:'0px'}}>{label}</Text>   
        <div style={{
          position: 'absolute',
          width: '120px', height: '40px',
          borderRadius: '8px',
          background: color
        }}>
        </div>
        <input
          type="color"
          name="hexBackgroundColor"
          onChange={handleChange}
          value={color}
          //   rounded
          style={{
            opacity: 0,
            padding: "0px",
            border: 'none',
            cursor: "pointer",
            margin: "0px",
            width: "120px",
            height: "40px",
          }}
        />
      </div>
    );
};

export default HighlightColor;