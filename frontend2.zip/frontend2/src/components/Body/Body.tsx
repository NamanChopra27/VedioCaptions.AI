'use client'
import { useIsMobile, useIsTablet } from '@/hooks/useMediaQuery';
import { Container } from '@nextui-org/react';
import { usePathname } from 'next/navigation';
import React, { ReactElement } from 'react';

const Body = ({ children }: any) => {
    const isMobile = useIsMobile();
    const isTablet = useIsTablet();
    const pathname = usePathname();

    const isPathname = pathname.includes("/dashboard");

    return (
        <Container fluid css={{
            m: 'auto', width: '100%',
            mx: (isMobile || isTablet) ? '0px' : 'auto',
            px: (isPathname && isTablet)?'30px':(isPathname && !isMobile) ? '60px' 
            : (isPathname && isMobile) ? '5px' : '0px',
            my: '0px',
            minHeight:'75vh',
            boxSizing: 'border-box'
        }}>
            {children}
        </Container>
    );
};

export default Body;