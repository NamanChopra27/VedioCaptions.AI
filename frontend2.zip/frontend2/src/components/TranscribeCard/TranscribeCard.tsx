import { CONSTS } from '@/constants';
import { Button, Container, Input, Popover, Text } from '@nextui-org/react';
import { IconArrowLeftTail, IconClock, IconCornerDownLeft, IconSTurnLeft } from '@tabler/icons';
import React, { useState } from 'react';
import styled from 'styled-components';

const TimeButton = styled.button<{ active: boolean }>`
    
`

const TranscribeCard = ({data}:any) => {
    const [isOpen, setIsOpen]=useState(false)
    const [acitve, setActive]=useState(false)

    const handleOpen=()=>{
        setIsOpen(!isOpen)
        setActive(!acitve)
    }

    return (
        <div>
            <Popover isOpen={isOpen} onOpenChange={handleOpen} isBordered disableShadow placement={'bottom-left'}>
                <Popover.Trigger>
                    <Button  auto flat rounded
                    css={{bg:acitve?CONSTS.BRAND_COLORS.PRIMARY:'#FFF1FF',
                color:acitve?'#FFF':'#000',
                }} 
                    >{`${data.start} - ${data.end}`}</Button>
                </Popover.Trigger>
                <Popover.Content css={{p:'10px',display:'block'}}>
                    <Text css={{display:'flex', mb:'10px',fontSize:'14px',
                    justifyContent:'center',alignItems:'center',gap:'5px'}}><IconClock size={'14px'}/> Change timeline</Text>
                    <Container display='block' css={{
                        display:'flex',
                        flexDirection:'column',
                        p:'0px',
                        justifyContent:'space-between',
                    }}>

                    <Input label='Start min 0' size='xs'  value={data.start} /><br/>
                    <Input label='End max 0.6' size='xs'  value={data.end} />
                    </Container>
                    <Container css={{
                        display:'flex',
                        p:'0px',
                        justifyContent:'space-between',
                        mt:'10px'
                    }}>
                        <Button size='xs' bordered light css={{color:'#acabab',borderColor:'#c7c2c2'}}>Cancel</Button>
                        <Button size='xs' css={{ bg: CONSTS.BRAND_COLORS.PRIMARY }}>Save</Button>

                    </Container>
                </Popover.Content>
            </Popover>
            <div style={{display:'flex',gap:'50px',alignItems:'center'}}>
                <Text>{data.text} </Text>
                <Text css={{display:'flex', justifyContent:'center',alignItems:'center'}}> <IconCornerDownLeft /> main event </Text>
            </div>

        </div>
    );
};

export default TranscribeCard;