"use client";
import { CONSTS } from "@/constants";
import UploadArrow from "@/icons/UploadArrow";
import { Button, Input, Modal, Spacer, Text, Loading } from "@nextui-org/react";
import { useRouter } from "next/navigation";
import React, { useState } from "react";
import { Toaster, toast } from "react-hot-toast";
import { styled } from "styled-components";
import { useSession } from "next-auth/react";
import Select from "react-select";
import { CreateSrt } from "@/apis/processApis";

const UploadDiv = styled.div`
  display: inline-flex;
  padding: 148px 270px;
  flex-direction: column;
  align-items: center;
  gap: 22.895px;
  border-radius: 20.813px;

  border: 2.081px solid var(--light, #edecff);
  background: #fff;
  box-shadow: 0px 12.67266px 17.42491px -6.33633px rgba(45, 54, 67, 0.04),
    0px 31.68166px 38.01799px -6.33633px rgba(45, 54, 67, 0.04);
  cursor: pointer;

  &:hover {
    border: 2.081px solid var(--light, #756dff);
  }
  @media (max-width: 1024px) {
    padding: 86px 96px;
  }

  @media (max-width: 512px) {
    padding: 80px 80px;
  }
`;
const Video = styled.video`
  width: 700px;
  height: 450px;

  @media (max-width: 768px) {
    width: 500px;
    height: 320px;
  }
  @media (max-width: 768px) {
    width: 320px;
    height: 240px;
  }
`;
const VideoDiv = styled.div`
  display: inline-flex;
  flex-direction: column;
  align-items: center;
  gap: 36px;
  margin-top: 5%;
`;
const UploadVideo = () => {
  const router = useRouter();
  const [selectedLanguage, setSelectedLanguage] = useState({
    value: "",
    label: "Auto Detect",
  });
  const [videoURL, setVideoURL] = useState<string>("");
  const [email, setEmail] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [isSelectOpen, setIsSelectOpen] = useState(false);
  const [visible, setVisible] = React.useState(false);
  const handler = () => setVisible(true);

  const session = useSession();
  console.log(session.data?.user?.email);

  const closeHandler = () => {
    setVisible(false);
    console.log("closed");
  };

  const languageOptions = [
    { value: "", label: "Auto Detect" },
    { value: "en", label: "English" },
    { value: "es", label: "Spanish" },
    { value: "fr", label: "French" },
    { value: "de", label: "German" },
    { value: "it", label: "Italian" },
    { value: "zh", label: "Chinese" },
    { value: "ru", label: "Russian" },
    { value: "pt", label: "Portugese" },
  ];
  //@ts-ignore
  const handleLanguageChange = (selectedOption) => {
    setSelectedLanguage(selectedOption);
    console.log(
      `Selected language: ${selectedOption ? selectedOption.value : "None"}`
    );
  };

  async function DownloadVideo() {
    try {
      setLoading(true);
      const formData = new FormData();
      //@ts-ignore
      formData.append("video", selectedFile);

      try {
        const response = await CreateSrt(formData);
        if (response) {
          //@ts-ignore
          console.log(response.url);
          const link = document.createElement("a");
          //@ts-ignore
          link.href = response.url;
          link.download = "output.mp4";
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);

          setLoading(false);
          setVisible(false);

        } else {
          throw new Error("Invalid response format");
        }
      } catch (error) {
        console.error("Error in API response:", error);
        // Handle error
        setLoading(false);
      }
    } catch (error) {
      // Handle error
      setLoading(false);
      console.error("Error generating video:", error);
    }
  }

  return (
    <>
      {videoURL ? (
        <VideoDiv>
          <Video controls>
            <source src={videoURL} type="video/mp4" />
            Your browser does not support the video tag.
          </Video>
          <div style={{ display: "flex", gap: "28px" }}>
            <Button
              onClick={() => {
                setVideoURL(""); // Reset videoURL
              }}
              css={{ backgroundColor: `${CONSTS.BRAND_COLORS.PRIMARY}` }}
            >
              Upload Another
            </Button>
            <Button
              onPress={handler}
              css={{ backgroundColor: `${CONSTS.BRAND_COLORS.PRIMARY}` }}
            >
              Process
            </Button>
          </div>
          <Spacer y={1} />
        </VideoDiv>
      ) : (
        <>
          <label htmlFor="videoUpload">
            <UploadDiv>
              {/* Your existing content */}
              <UploadArrow />
              <Text size={30}>Upload Video</Text>
              <div
                style={{
                  display: "flex",
                  gap: "10px",
                  flexDirection: "column",
                  textAlign: "center",
                }}
              >
                <Text
                  weight={"normal"}
                  size={14}
                  css={{
                    color: "#737373",
                    width: "200px",
                    textAlign: "center",
                  }}
                >
                  MP4, MOV formats & 1:1, 4:5, 9:16 ratio accepted
                </Text>
                <Text
                  weight={"normal"}
                  size={14}
                  css={{
                    color: "#737373",
                    textAlign: "center",
                    width: "200px",
                  }}
                >
                  (Max 91s, for now)
                </Text>
              </div>
            </UploadDiv>
          </label>
        </>
      )}
      <input
        type="file"
        name="videoUpload"
        id="videoUpload"
        accept="video/*"
        style={{ display: "none" }}
        onChange={(e) => {
          //@ts-ignore
          const file = e.target.files[0];
          console.log("Selected File:", file);

          if (file) {
            const videoURL = URL.createObjectURL(file);
            console.log("Video URL:", videoURL);

            setVideoURL(videoURL);
            setSelectedFile(file); // Save the selected file in the state
          }
        }}
      />
      <Toaster position="top-center" reverseOrder={false} />
      <Modal
        closeButton
        aria-labelledby="modal-title"
        open={visible}
        onClose={closeHandler}
        css={{ height: isSelectOpen ? "70vh" : "auto" }}
      >
        <Modal.Header css={{ display: "flex", flexDirection: "column" }}>
          <Text id="modal-title" size={18}>
            Select Language and press Button To Process and download Video
          </Text>
          <div></div>
        </Modal.Header>
        <Modal.Body>
          <Select
            value={selectedLanguage}
            onChange={handleLanguageChange}
            options={languageOptions}
            placeholder="Select a language"
            onMenuOpen={() => setIsSelectOpen(true)}
            onMenuClose={() => setIsSelectOpen(false)}
            styles={{
              menu: (provided) => ({
                ...provided,
                zIndex: 9999, // Set a high z-index value to ensure it appears above other elements
              }),
            }}
          />
          <Button
            disabled={loading}
            css={{ marginTop: "$8" }}
            onPress={DownloadVideo}
          >
            {!loading ? <>Generate Video</> : <>Generating Video</>}
            &nbsp;{" "}
            {loading && (
              <Loading type="points-opacity" color="currentColor" size="sm" />
            )}
          </Button>
        </Modal.Body>
        <Modal.Footer></Modal.Footer>
      </Modal>
    </>
  );
};

export default UploadVideo;
