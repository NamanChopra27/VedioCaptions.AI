import React from 'react';
import styled from 'styled-components';

interface StatusPillProps {
  children: React.ReactNode;
  color: string;
  backgroundColor: string;
}

const CapsuleDiv = styled.div<StatusPillProps>`
    display: flex;
    height: 20px;
    padding: 0px 8px;
    align-items: center;
    gap: 2px;
    border-radius: 18px;
    background: ${props => props.backgroundColor};
    color: ${props => props.color};
    text-align: center;
    font-size: 15px;
    font-style: normal;
    font-weight: 400;
    line-height: 20px; 
    text-transform: capitalize;
`;

const StatusPill = ({ children, color, backgroundColor }: StatusPillProps) => {
  return (
    <CapsuleDiv color={color} backgroundColor={backgroundColor}>
         {children}
    </CapsuleDiv>
  )
}

export default StatusPill
