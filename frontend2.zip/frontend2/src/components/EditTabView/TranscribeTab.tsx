import React from 'react';
import styled from 'styled-components';
import TranscribeCard from '../TranscribeCard/TranscribeCard';


export const MainCard = styled.div`
display: flex;
width: 374px;
padding: 32px;
flex-direction: column;
align-items: flex-start;
gap: 32px;
border-radius: 20px;
background: #FFF;

/* Xl */
box-shadow: 0px 24px 50px -12px rgba(45, 54, 67, 0.12);
`
export const MainContainer = styled.div`
padding: '20px';
width: 'fit-content';
`
const TranscribeTab = () => {

    const transcribeCards = [
        { start: '0.1', end: '0.2', text: "hello" },
        { start: '0.2', end: '0.3', text: "hello" },
        { start: '0.3', end: '0.4', text: "hello" },
        { start: '0.4', end: '0.5', text: "hello" },]

    return (
        <MainContainer >
            <MainCard>
                {transcribeCards.map((card, index) => {
                    return <TranscribeCard key={index} data={card} />
                })}

            </MainCard>
        </MainContainer>
    );
};

export default TranscribeTab;