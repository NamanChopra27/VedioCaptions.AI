import React from 'react';
import { MainCard, MainContainer } from './TranscribeTab';
import ThemeCard from '../ThemeCard/ThemeCard';
import { Input, Text } from '@nextui-org/react';
import styled from 'styled-components';
import HighlightColor from '../HighlightColorView/HighlightColor';


const Slider=styled.input`
border:none;
width:115px;
height:5px;
color: green;
`

const DesignTab = () => {

    const themes = [
        { src: '/assets/themes/hormozi1.png' },
        { src: '/assets/themes/hormozi2.png' },
        { src: '/assets/themes/hormozi3.png' },
        { src: '/assets/themes/devin.png' },
        { src: '/assets/themes/beast.png' },
        { src: '/assets/themes/ali.png' },
        { src: '/assets/themes/david.png' },
        { src: '/assets/themes/iman.png' },
    ]

    return (
        <MainContainer>
            <MainCard>
                <Text h4>Themes</Text>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px', margin: 'auto' }}>

                    {themes.map((theme, index) => {
                        return <ThemeCard key={index} src={theme.src} />
                    })}
                </div>
                <div>

                <div style={{ display: 'flex', gap: '10px' }}>
                    <Input label='Color' size='sm' bordered />
                    <Input label='Size (px)' size='sm' bordered />
                    <Input label='Position Y (%)' size='sm' bordered />
                </div>
                <div style={{ display: 'flex',marginTop:'10px',gap: '10px',width:'100%', alignItems: 'flex-end',justifyContent:'end' }}>
                  <Slider min={1} max={10} type='range'/>
                  <Slider min={1} max={10} type='range'/>

                </div>
                </div>
                <div>

                <Text  css={{fontSize:'16px',m:'0px',}}>Highlight colors</Text>
                <div style={{ display: 'flex', gap: '10px' }}>
                <HighlightColor color='#267825' label='Main color'/>
                <HighlightColor color='#FFD02B' label='Second color'/>
                <HighlightColor color='#DC372A' label='Third color'/>
                </div>
                </div>

            </MainCard>

        </MainContainer>
    );
};

export default DesignTab;