'use client'
import React, { useState } from 'react';
import styled from 'styled-components';
import TranscribeTab from './TranscribeTab';
import DesignTab from './DesignTab';
import DescriptionTab from './DescriptionTab';
import { Image } from '@nextui-org/react';

type Tab = {
    label: string;
    content: React.ReactNode;
  };

const TabField=styled.div`
display:flex;
margin: auto;
width: fit-content;
padding: 0.5rem;
background-color: #fcfcfc;
border-radius: 2rem;
gap:1rem;
`
const TabButton = styled.button<{ active: boolean }>`
  background-color: ${({ active }) => (active ? '#FFFFFF' : '#fcfcfc')};
  color: ${({ active }) => (active ? '#1F2937' : '#4B5563')};
  border-radius: 2rem;
  padding: 1rem 1.5rem;
  font-weight:  ${({ active }) => (active ? '700' : '500')};;
  border: none;
  outline: none;
  cursor: pointer;
  box-shadow:${({ active }) => (active ?'0px 10px 20px -11px rgba(8, 8, 8, 0.2);' :'none')};
  transition: box-shadow .1s ease-in-out;

`;
const TabViewContent = styled.div`
  margin-top: 1rem;
  height: 40rem;
  overflow-y: auto;
  overflow-x: hidden;
  padding: 1rem;
`;

const EditTabView = () => {
      
        const [activeTab, setActiveTab] = useState(0);
      
        const tabs :Tab[] = [
            {
              label: 'Transcribe',
              content: <TranscribeTab/>
            },
            {
              label: 'Design',
              content: <DesignTab/>,
            },
            {
              label: 'Description',
              content: <DescriptionTab/>,
            },
          ];

        const handleTabClick = (index: number) => {
          setActiveTab(index);
        };

        return (
            <div style={{margin:'auto' ,gap:'20px',
            width:'fit-content',display:'flex'}} >
                <div>

              <TabField>
                {tabs.map((tab, index) => (
                  <TabButton
                    key={index}
                    active={activeTab === index}
                      
                    onClick={() => handleTabClick(index)}
                    >
                    {tab.label}
                  </TabButton>
                ))}
              </TabField>
              <TabViewContent >{tabs[activeTab].content}</TabViewContent>
                </div>
                <div>
                    <Image width={'300px'} src={'/assets/videodemo.png'}/>
                </div>
            </div>
          );
        };
    
export default EditTabView;