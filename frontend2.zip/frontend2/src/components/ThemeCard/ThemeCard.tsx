import { Button, Image } from '@nextui-org/react';
import { IconEdit } from '@tabler/icons';
import React from 'react';

const ThemeCard = ({src}:any) => {
    return (
        <div style={{width:'fit-content', alignContent:'center'}}>
            <Image src={src} height={'40px'}/>
            <Button light bordered size={'xs'} css={{color:'$gray300',borderColor:'$gray300',margin:'auto',my:'10px'}}><IconEdit/> Custom</Button>
            
        </div>
    );
};

export default ThemeCard;