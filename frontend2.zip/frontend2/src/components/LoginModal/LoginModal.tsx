import { Modal, Text, Spacer, Button, Loading } from "@nextui-org/react";
import { signIn } from "next-auth/react";
import styled from "styled-components";
import React from "react";
import GreenTick from "@/icons/GreenTick";
import { CONSTS } from "@/constants";

const FirstPurchaseBox = styled.div`
  display: inline-flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  gap: 35px;
`;
const PurchaseBoxText = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  color: #5d6368;
`;
const PurchaseBoxDivider = styled.div`
  border: none;
  border-top: 1px solid var(--main-linke, #e5e7eb);
`;
const SignInDiv = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  border-radius: 4px;
  width: 280px;
  height: 52px;
  border-radius: 14px;
  border: 1px solid #4f86ec;
  cursor: pointer;

`;
const ModalDiv=styled.div`


`
const ModalHeading=styled.div`
 display: flex;
 justify-content: center;
 align-items: center;
 margin-bottom: 10px;
 @media only screen and (max-width: 350px) {
   flex-direction: column;
  }
 
`
const SignInTextDiv = styled.div`
  height: 52px;
  display: flex;
  justify-content: center;
  align-items: center;
  width: 250px;
  border-top-right-radius: 12px;
  border-bottom-right-radius: 12px;
  border: none;

 
`;
const LoginModal = ({
  visible,
  setVisible,
}: {
  visible: boolean;
  setVisible: (val: boolean) => void;
}) => {
  const closeHandler = () => {
    setVisible(false);
    console.log("closed");
  };

  const handleSignIn = (provider: string) => {
    signIn(provider, { callbackUrl: "/" });
  };

  return (
    <Modal
      closeButton
      aria-labelledby="modal-title"
      open={visible}
      onClose={closeHandler}
    >
      <Modal.Body
        css={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          padding:"5px",
        }}
      >
        <FirstPurchaseBox>
          <ModalDiv >
            <ModalHeading>
              <Text size={22} b css={{ margin: 0 }}>
                Sign in now
              </Text>
              <PurchaseBoxText style={{ fontSize: "15px" }}>
               &nbsp;(No Credit Card Required)
              </PurchaseBoxText>
            </ModalHeading>
            <div style={{ display: "flex", alignItems: "baseline" }}>
              <Text size={30} b style={{textDecoration:"line-through"}}>
                $14 {/* TODO: need to change the price base on the product*/}
              </Text>
              &nbsp;
              <Text style={{ color: "#94A3B8" }}>Per Month</Text>
              &nbsp;
              
              <Text size={30} b style={{color:"#00BE13"}}>
               FREE
              </Text>
             
            </div>
            <PurchaseBoxDivider></PurchaseBoxDivider>
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "flex-start",
                marginTop: "20px",
                gap: "10px",
              }}
            >
              <PurchaseBoxText>
                <GreenTick />
                &nbsp; No WaterMark
              </PurchaseBoxText>

              <PurchaseBoxText>
                <GreenTick /> &nbsp; Edit Multiple Pass
              </PurchaseBoxText>
              <PurchaseBoxText>
                <GreenTick /> &nbsp; View Pass Usage Stats
              </PurchaseBoxText>
            </div>
          </ModalDiv>
          <Button size={'lg'} css={{
            bg:'white',
            border:`1px solid ${CONSTS.BRAND_COLORS.PRIMARY}`,
            padding:"20px 0px",
          }} onClick={() => handleSignIn("google")}>
            &nbsp;
            <img
              style={{ height: "20px", width: "20px", padding: "10px" }}
              src="google.png"
            ></img>
            <SignInTextDiv
              style={{ backgroundColor: CONSTS.BRAND_COLORS.PRIMARY }}
            >
              <Text
                weight={"medium"}
                color={"white"}
                size={16}
                css={{ margin: 0 }}
              >
                Sign in with Google
              </Text>
            </SignInTextDiv>
          </Button>
        </FirstPurchaseBox>
      </Modal.Body>
      <Modal.Footer />
    </Modal>
  );
};

export default LoginModal;
