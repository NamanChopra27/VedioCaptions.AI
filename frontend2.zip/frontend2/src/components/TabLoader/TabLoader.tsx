import React from "react";
import styled, { keyframes } from "styled-components";

const spin78236 = keyframes`
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
`;

const wobble1 = keyframes`
  0%,
  100% {
    transform: translateY(0%) scale(1);
    opacity: 1;
  }
  50% {
    transform: translateY(-66%) scale(0.65);
    opacity: 0.8;
  }
`;

const wobble2 = keyframes`
  0%,
  100% {
    transform: translateY(0%) scale(1);
    opacity: 1;
  }
  50% {
    transform: translateY(66%) scale(0.65);
    opacity: 0.8;
  }
`;

const ThreeBodyContainer = styled.div`
  --uib-size: 35px;
  --uib-speed: 0.8s;
  --uib-color: #6359fd;
  position: relative;
  display: inline-block;
  height: var(--uib-size);
  width: var(--uib-size);
  animation: ${spin78236} calc(var(--uib-speed) * 2.5) infinite linear;
`;

const ThreeBodyDot = styled.div`
  position: absolute;
  height: 100%;
  width: 30%;

  &:after {
    content: "";
    position: absolute;
    height: 0%;
    width: 100%;
    padding-bottom: 100%;
    background-color: var(--uib-color);
    border-radius: 50%;
  }
`;

const FirstDot = styled(ThreeBodyDot)`
  bottom: 5%;
  left: 0;
  transform: rotate(60deg);
  transform-origin: 50% 85%;

  &:after {
    bottom: 0;
    left: 0;
    animation: ${wobble1} var(--uib-speed) infinite ease-in-out;
    animation-delay: calc(var(--uib-speed) * -0.3);
  }
`;

const SecondDot = styled(ThreeBodyDot)`
  bottom: 5%;
  right: 0;
  transform: rotate(-60deg);
  transform-origin: 50% 85%;

  &:after {
    bottom: 0;
    left: 0;
    animation: ${wobble1} var(--uib-speed) infinite
      calc(var(--uib-speed) * -0.15) ease-in-out;
  }
`;

const ThirdDot = styled(ThreeBodyDot)`
  bottom: -5%;
  left: 0;
  transform: translateX(116.666%);

  &:after {
    top: 0;
    left: 0;
    animation: ${wobble2} var(--uib-speed) infinite ease-in-out;
  }
`;

const TabLoader = () => {
  return (
    <>
      <ThreeBodyContainer>
        <FirstDot />
        <SecondDot />
        <ThirdDot />
      </ThreeBodyContainer>
    </>
  );
};

export default TabLoader;
