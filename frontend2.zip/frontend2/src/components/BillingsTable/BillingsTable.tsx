import {
  Container,
  Loading,
  Text,
  Pagination,
} from "@nextui-org/react";
import React from "react";
import { styled } from "styled-components";
import Link from "next/link";
import DownloadIcon from "@/icons/DownloadIcon";
import { useEffect, useState } from "react";
import StatusPill from "../StatusPill/StatusPill";
const PaymentsDiv = styled.div`
  display: flex;
  width: max-content;
  flex-direction: column;
  align-items: flex-start;
  gap: 20px;
`;
const BillingsTablediv = styled.div`
  display: flex;
  padding: 20px;
  flex-direction: column;
  align-items: flex-start;
  gap: 14px;
  border-radius: 20px;
  border: 1px solid #f9f9f9;
  background: #fff;
  box-shadow: 0px 8px 11px -4px rgba(45, 54, 67, 0.04),
    0px 20px 24px -4px rgba(45, 54, 67, 0.04);
      overflow-x: auto; /* Enable horizontal scrolling */
      max-width:75vw;
`;
const TableHeadRow = styled.div`
  display: flex;
  align-items: flex-start;
  gap: 1px;
  border-radius: 7px;
  box-shadow: 0px 8px 11px -4px rgba(45, 54, 67, 0.04),
    0px 20px 24px -4px rgba(45, 54, 67, 0.04);
`;
const TableCell = styled.div`
  display: flex;
  width: 12vw;
  padding: 22px 11px 22px 10px;
  align-items: center;
  justify-content: space-evenly;
  gap: 1px;
  border-radius: 10px 0px 0px 10px;
  border-right: 1px solid #dedede;
`;
const TableBodyDiv = styled.div`
  display: flex;
  align-items: flex-start;
  gap: 1px;
`;

const BillingsTable = ({
  transactions,
  loading,
}: {
  transactions: any;
  loading: boolean;
}) => {
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  const handlePageChange = (newPage: number) => {
    setCurrentPage(newPage);
  };

  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  let displayedTransactions = [];

  if (transactions && transactions.transactions) {
    displayedTransactions = transactions.transactions.slice(
      startIndex,
      endIndex
    );
  }

  const formatTimestamp = (timestamp: any) => {
    const date = new Date(timestamp * 1000);
    return date.toLocaleDateString();
  };

  return (
    <>
      {loading ? (
        <Container
          css={{
            display: "flex",
            h: "90vh",
            w: "auto",
            jc: "center",
            ai: "center",
          }}
        >
          <Loading type="spinner" size={"xl"} css={{ color: "#6359fd" }} />
        </Container>
      ) : (
        <>
          {transactions && (
            <>
              <PaymentsDiv>
                <Text b size={20}>
                  Payments
                </Text>
                <BillingsTablediv>
                  <TableHeadRow>
                    <TableCell style={{ width: "125px" }}>Date</TableCell>
                    <TableCell style={{ width: "275px" }}>
                      Transaction Id
                    </TableCell>
                    <TableCell style={{ width: "235px" }}>
                      Billing Reason
                    </TableCell>
                    <TableCell style={{ width: "125px" }}>Amount</TableCell>
                    <TableCell style={{ width: "125px" }}>Status</TableCell>
                    <TableCell style={{ border: "none", width: "125px" }}>
                      Invoice
                    </TableCell>
                  </TableHeadRow>
                  {displayedTransactions.map((transaction: any, index: any) => (
                    <TableBodyDiv
                      key={index}
                      style={{
                        backgroundColor:
                          index % 2 === 0 ? "#f5faff" : "inherit",
                      }}
                    >
                      <TableCell style={{ width: "125px" }}>
                        {formatTimestamp(transaction.created)}
                      </TableCell>
                      <TableCell style={{ width: "275px" }}>
                        {transaction.id}
                      </TableCell>
                      <TableCell style={{ width: "235px" }}>
                       {transaction.billing_reason.replace(/_/g, ' ')}d
                      </TableCell>
                      <TableCell style={{ width: "125px" }}>
                        ${transaction.amount_paid / 100}
                      </TableCell>
                      <TableCell style={{ width: "125px" }}>
                        
                        {transaction.status==="paid"?(
                        <StatusPill color="#00BE13" backgroundColor="#c8ffcd">
                          paid
                        </StatusPill>
                        ):<StatusPill color="#F5222D" backgroundColor="#fad3d0">
                          Processing
                          </StatusPill>}
                       
                      </TableCell>
                      <TableCell style={{ border: "none", width: "125px" }}>
                        {transaction?.receipt_url ? (
                          <Link href={transaction?.receipt_url} target="_blank">
                            <DownloadIcon />
                          </Link>
                        ) : <StatusPill color="#FA0" backgroundColor="#ffeecd">
                          Trial
                          </StatusPill>}
                      </TableCell>
                    </TableBodyDiv>
                  ))}
                  <div
                    style={{
                      display: "flex",
                      width: "100%",
                      justifyContent: "center",
                      alignItems: "center",
                    }}
                  >
                    {transactions.transactions.length > 8 && (
                      <Pagination
                        total={Math.ceil(
                          transactions.transactions.length / itemsPerPage
                        )}
                        onChange={handlePageChange}
                      />
                    )}
                  </div>
                </BillingsTablediv>
              </PaymentsDiv>
            </>
          )}
        </>
      )}
    </>
  );
};

export default BillingsTable;
