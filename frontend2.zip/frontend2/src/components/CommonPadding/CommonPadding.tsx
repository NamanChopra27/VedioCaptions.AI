import { Container, Spacer } from "@nextui-org/react";
//@ts-ignore
export default function CommonPadding({ children, gap = 2, css = {} }) {
  return (
    <Container gap={gap} css={css}>
      <Spacer y={1} />
      {children}
      <Spacer y={1} />
    </Container>
  );
}
