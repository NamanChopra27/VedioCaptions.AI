import { CONSTS } from '@/constants';
import { Button, Text } from '@nextui-org/react';
import { IconCheck } from '@tabler/icons';
import React from 'react';
import styled from 'styled-components';

const MainContainer = styled.div<{ borderColor: string }>`
    display:flex;
    position: relative;
    flex-direction: column;
    border-radius: 10px;
    width: 300px;
    height: 500px;
    padding: 20px;
    border: 2px solid ${({ borderColor }) => borderColor};

`

const PriceCard = ({ pricing }: any) => {


    return (
        <MainContainer borderColor={pricing.border}>
            <Text h2 css={{ textAlign: 'center' }}>{pricing.title}</Text>
            <Text css={{ textAlign: 'center',color:'$gray700', fontWeight:'lighter',my:'10px' }}>{pricing.description}</Text>
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'baseline', gap: '10px', width: '100%' }}>
                <Text h1 css={{ fontWeight: '$bold',fontSize:'$xl6' }}>{pricing.amount}</Text>
                <Text css={{color:'$gray700',}}>/month</Text>
            </div>
            <Text css={{ textAlign: 'center', fontWeight: '$thin',color:'$gray700', }}>Billed monthly</Text>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px',paddingTop:'30px' }}>
                {
                    pricing.features?.map((feat: any, index: any) => {
                        return <div key={index} style={{ display: 'flex', 
                        gap: '30px', justifyContent: 'left', alignItems: 'center' }}>
                            <IconCheck color='green' style={{}} /> 
                            <Text css={{textAlign: 'left',width:'80%', fontWeight: '$thin',color:'$gray800' }}>

                            {feat}
                            </Text>
                            </div>
                    })
                }
            </div>

            <Button rounded css={{
                bg: CONSTS.BRAND_COLORS.PRIMARY,
                position: 'absolute', bottom: '10px',
                alignSelf: 'center'
            }} >Pay Now</Button>

        </MainContainer>
    );
};

export default PriceCard;