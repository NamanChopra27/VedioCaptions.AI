'use client'
import { Container, Link, Row } from "@nextui-org/react";
import styled from "styled-components";
import { useEffect, useState } from "react";
import { useIsMobile } from "@/hooks/useMediaQuery";

// StyleS
const FooterLink = styled(Link)<{isMobile?:boolean}>`
  color: grey;
  margin: ${(props) => (props.isMobile ? "0px 0px 0px 20px" : '0px 10px')};
  :hover {
    color: #312f2f;
  }
  &:last-child {
    margin-right: 0px;
  }
`;

const FooterContainer = styled(Container)`
  flex-direction: column;
  border-top: 1px solid lightgrey;
  margin-top: 40px;
`;

const FooterRow = styled(Row)`
  padding: 20px;
`;

const FooterColumnLeft = styled(Row)``;
const FooterColumnRight = styled(Row)`
  justify-content: flex-end;
`;
// Style ends
const currYear = new Date().getFullYear();

export default function Footer() {
  const isMobile=useIsMobile();
  return (
    <FooterContainer gap={0} direction="column" css={{}}>
      <FooterRow style={{justifyContent:'space-between'}}>
        <FooterColumnLeft>
          © {currYear} Enrich Hosting Private Limited. All Rights Reserved.
        </FooterColumnLeft>
        <FooterColumnRight style={{display:isMobile?'block':'flex',textAlign:isMobile?'right':'left',}}>
          {/* <FooterLink href={Routes.aboutUsPage.path}>About us</FooterLink> */}
          <FooterLink isMobile={isMobile} href={"faqs"}>FAQs</FooterLink>
          <FooterLink isMobile={isMobile} href={"terms"}>Terms</FooterLink>
          <FooterLink isMobile={isMobile} href={"privacy-policy"}>Privacy Policy</FooterLink>
          <FooterLink isMobile={isMobile} href={"about-us"}>About Us</FooterLink>
          <FooterLink isMobile={isMobile} href={"contact-us"}>Contact Us</FooterLink>
        </FooterColumnRight>
      </FooterRow>
    </FooterContainer>
  );
}
