import { deleteSubscription,stripeCheckout } from "@/apis/paymentsApis";
import { CONSTS } from "@/constants";
import toast from "react-hot-toast";
import {
  Modal,
  Button,
  Text,
  Loading,
} from "@nextui-org/react";
import { useRouter } from "next/navigation";
import React, { useState } from "react";
import { styled } from "styled-components";

const SubscriptionDetailsDiv = styled.div`
  display: flex;
  align-items: center;
  gap: 30px;
  @media only screen and (max-width: 1024px) {
    flex-direction: column;
    align-items: flex-start;
  }
`;
const SubscriptionText = styled.div`
  display: flex;
  padding: 20px;
  justify-content: flex-end;
  gap: 20px;
  border-radius: 20px;
  border: 1px solid #f9f9f9;
  background: #fff;
  box-shadow: 0px 8px 11px -4px rgba(45, 54, 67, 0.04),
    0px 20px 24px -4px rgba(45, 54, 67, 0.04);
  @media only screen and (max-width: 512px) {
    flex-direction: column-reverse;
  }
`;
const SubscriptionTextRow = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 20px;
`;
const SubscriptionTextCell = styled.div`
  display: flex;
  padding: 12px 10px 12px 12px;

  gap: 10px;
  width: 95%;
  border-radius: 10px;
  background: #f8f8f8;
  color: #737373;
  font-size: 16px;
  line-height: 20px;
`;
const BlackText = styled.div`
  font-size: 16px;
  color: #000;
`;

const CardDiv = styled.div`
  display: flex;
  padding: 20px;
  flex-direction: column;
  align-items: flex-start;
  gap: 14px;
  border-radius: 20px;
  background: #fff;
  box-shadow: 0px 8px 11px -4px rgba(45, 54, 67, 0.04),
    0px 20px 24px -4px rgba(45, 54, 67, 0.04);
`;

const Paymentcard = styled.div`
  width: 380px;
  height: 220px;
  border-radius: 25px;
  background-color: #040404;

  @media only screen and (max-width: 480px) {
    width: 300px;
    height: 180px;
  }
`;
const CardDivider = styled.hr`
  width: 90%;
  margin-left: 2%;
  background-color: rgba(249, 249, 249, 0.21);
  border: none;
  height: 1px; /* This will make the hr as thin as possible */
`;

const SubscriptionDetails = ({
  subscriptiondata,
}: {
  subscriptiondata: any;
}) => {
  const [canceling, setCanceling] = useState(false);
  const [visible, setVisible] = React.useState(false);
  
  const handler = () => setVisible(true);

  const router = useRouter();
  const closeHandler = () => {
    setVisible(false);
  };
  const formatTimestamp = (timestamp: any) => {
    const date = new Date(timestamp * 1000);
    return date.toLocaleDateString();
  };

  const handleSubscriptionDelete = async () => {
    setCanceling(true);
    await deleteSubscription();

  
    setTimeout(() => {
      setVisible(false);
      if (typeof window !== "undefined") {
        window.location.reload();
      }
    }, 6000);
  };
  const handleClick = async () => {
    try {
      const res = await stripeCheckout({path: "billings"});
      //@ts-ignore
      window.location.href = res.url;
    } catch (error) {
      toast("Payment Failed", {
        position: "top-right",
        style: {
          width: "15vw",
          borderRadius: "16px",
          fontSize: "16px",
          color: "#B1000F",
          backgroundColor: "#FFD4D8",
        },
      });
      console.error("Payment false:", error);
    }
  };
  return (
    <>
      {subscriptiondata && (
        <div>
          <Text size={20} b>
            Subscription Details
          </Text>
          <SubscriptionDetailsDiv>
            <SubscriptionText>
              <SubscriptionTextRow>
                <SubscriptionTextCell>
                Subscription Started On{" "}
                  <BlackText>
                    {formatTimestamp(subscriptiondata.start_date)}
                  </BlackText>{" "}
                </SubscriptionTextCell>
                <SubscriptionTextCell>
                  Current Period start{" "}
                  <BlackText>
                    {formatTimestamp(subscriptiondata.current_period_start)}
                  </BlackText>
                </SubscriptionTextCell>
                <SubscriptionTextCell>
                  Amount{" "}
                  <BlackText>${subscriptiondata.plan.amount / 100}</BlackText>
                </SubscriptionTextCell>
                {!subscriptiondata?.cancel_at_period_end ? (
                  <>
                    {" "}
                    {subscriptiondata?.status==="trialing" ? (
                      <>
                        <Button style={{backgroundColor:CONSTS.BRAND_COLORS.PRIMARY}} onPress={handleClick}>
                          Subscribe Now
                        </Button>
                        
                      </>
                    ) : <>
                       
                        <Button color={"error"} flat onPress={handler}>
                          Cancel Subscription
                        </Button>
                        <Modal
                          closeButton
                          aria-labelledby="modal-title"
                          open={visible}
                          onClose={closeHandler}
                        >
                          <Modal.Header>
                            <Text b size={18}>
                              Confirm Cancellation
                            </Text>
                          </Modal.Header>
                          <Modal.Body>
                            Please note that your access to premium features
                            will continue until the end of your current billing
                            cycle. You will not be charged any further beyond
                            that date.
                          </Modal.Body>
                          <Modal.Footer>
                            <Button
                              disabled={canceling}
                              color={"error"}
                              onPress={handleSubscriptionDelete}
                            >
                              Cancel Subscription
                              {canceling && (
                                <>
                                  &nbsp;
                                  <Loading
                                    type="spinner"
                                    color="currentColor"
                                    size="sm"
                                  />
                                </>
                              )}
                            </Button>
                          </Modal.Footer>
                        </Modal>
                      </>}
                  </>
                ) : (
                  <SubscriptionTextCell
                    style={{ background: "#fef0d3", color: "#FA0" }}
                  >
                    Subscription will be cancelled on{" "}
                    <BlackText style={{ color: "#FA0" }}>
                      {formatTimestamp(subscriptiondata.current_period_end)}
                    </BlackText>
                  </SubscriptionTextCell>
                )}
              </SubscriptionTextRow>
              <SubscriptionTextRow>
                <SubscriptionTextCell>
                  Status <BlackText>{subscriptiondata.status}</BlackText>
                </SubscriptionTextCell>
                <SubscriptionTextCell>
                  Current Period end{" "}
                  <BlackText>
                    {formatTimestamp(subscriptiondata.current_period_end)}
                  </BlackText>
                </SubscriptionTextCell>
                <SubscriptionTextCell>
                  Interval{" "}
                  <BlackText>{subscriptiondata.plan.interval}ly</BlackText>
                </SubscriptionTextCell>
              </SubscriptionTextRow>
            </SubscriptionText>

            {subscriptiondata.payment_method_details && (
              <>
                <CardDiv>
                  <Text>Payment Details</Text>
                  <Paymentcard>
                    <div
                      style={{
                        width: "100%",
                        height: "100%",
                        display: "flex",
                        justifyContent: "space-between",
                        flexDirection: "column",
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                          width: "100%",
                          marginLeft: "2%",
                          marginRight: "8%",
                          marginTop: "2%",
                        }}
                      >
                        <Text size={14} color="#fff">
                          {subscriptiondata.payment_method_details.card.brand}
                        </Text>
                        <Text size={14} color="#fff">
                          {subscriptiondata.payment_method_details.card.funding}
                        </Text>
                      </div>
                      <div
                        style={{
                          display: "flex",
                          flexDirection: "column",
                          marginLeft: "2%",
                        }}
                      >
                        <Text color="#fff" size={20}>
                          XXXX XXXX XXXX{" "}
                          {subscriptiondata.payment_method_details.card.last4}
                        </Text>

                        <CardDivider />
                        <div
                          style={{
                            display: "flex",
                            justifyContent: "space-between",
                            width: "100%",
                            marginLeft: "2%",
                            marginRight: "8%",
                            marginTop: "2%",
                            marginBottom: "2%",
                          }}
                        >
                          <Text size={14} color="#fff">
                            {subscriptiondata.payment_method_details.card.brand}
                          </Text>
                          <Text size={14} color="#fff">
                            {subscriptiondata.payment_method_details.card
                              .exp_month +
                              "/" +
                              subscriptiondata.payment_method_details.card
                                .exp_year}
                          </Text>
                        </div>
                      </div>
                    </div>
                  </Paymentcard>
                </CardDiv>
              </>
            )}
          </SubscriptionDetailsDiv>
        </div>
      )}
    </>
  );
};

export default SubscriptionDetails;
