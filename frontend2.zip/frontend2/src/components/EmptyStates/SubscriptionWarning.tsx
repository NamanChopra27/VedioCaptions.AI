import WarningIcon from '@/icons/warning';
import { Button, Card, Text } from '@nextui-org/react';
import { useRouter } from 'next/navigation';
import React from 'react';

const SubscriptionWarning = () => {
    const router = useRouter();

    const handleSubscribeNow = () => {
        router.push("/billings");
      };
    return (
        <Card variant="bordered" css={{ alignItems: "center",m:'auto',padding:'10px',width:'90%',mt:'10px' }}>
        <Card.Body>
          <WarningIcon  />
          <Text b color={"#737373"} css={{textAlign:'center'}}>
            Stats are not available because you do not have an
            active subscription.
          </Text>
          <Button
            color="warning"
            flat
            style={{ marginTop: "20px" }}
            onPress={handleSubscribeNow}
          >
            Subscribe Now
          </Button>
        </Card.Body>
      </Card>
    );
};

export default SubscriptionWarning;