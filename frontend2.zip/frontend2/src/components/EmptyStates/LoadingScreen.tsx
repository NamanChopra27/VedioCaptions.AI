import { CONSTS } from '@/constants';
import { Container, Loading } from '@nextui-org/react';
import React from 'react';

const LoadingScreen = () => {
    return (
        <Container
        css={{
          display: "flex",
          h: "90vh",
          w: "auto",
          jc: "center",
          ai: "center",
        }}
      >
        <Loading type="spinner" size={"xl"} css={{ color: CONSTS.BRAND_COLORS.PRIMARY }} />
      </Container>
    );
};

export default LoadingScreen;