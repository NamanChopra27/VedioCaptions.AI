import { CONSTS } from "@/constants";
import { Button, Container, Link } from "@nextui-org/react";
import React from "react";
import Routes from "../../../routes";

const EmptyMyCards = () => {
  return (
    <Container
      css={{
        textAlign: "center",
        display: "flex",
        w: "fit-content",
        flexDirection: "column",
        alignItems: "center",
      }}
    >
      It seems you have not created any Cards yet!
      <Link
        href={Routes.homePage.path}
        css={{
          bg: CONSTS.BRAND_COLORS.PRIMARY,
          alignSelf: "center",
          color: "white",
          borderRadius: "10px",
          p: "10px",
          mt: "20px",
        }}
      >
        Create New Card
      </Link>
    </Container>
  );
};

export default EmptyMyCards;
