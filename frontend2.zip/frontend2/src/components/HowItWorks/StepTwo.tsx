import React from 'react';
import { StepCounter, StepDescription, StepMainDiv, StepTitle } from './CommonElements';

const StepTwo = () => {
    //TODO: need to change the contents
    return (
        <StepMainDiv>
        <StepCounter>2</StepCounter>
        <StepTitle>Lorem ipsum dolor sit amet  </StepTitle>
        <StepDescription>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate nulla veniam iusto blanditiis ad. Dolorum, sunt. Corporis odit quasi eligendi quis pariatur quibusdam autem perspiciatis, obcaecati nisi. Nam, sunt tempore?</StepDescription>
        <StepDescription>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsum cumque corrupti, nihil assumenda mollitia quam. Ex amet unde minus consectetur.</StepDescription>

        
    </StepMainDiv>
    );
};

export default StepTwo;