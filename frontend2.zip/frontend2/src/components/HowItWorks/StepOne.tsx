import React from 'react';
import { StepCounter, StepDescription, StepMainDiv, StepTitle } from './CommonElements';

const StepOne = () => {
    //TODO: need to change the contents
    return (
        <StepMainDiv>
            <StepCounter>1</StepCounter>
            <StepTitle>Lorem ipsum dolor sit  </StepTitle>
            <StepDescription> Lorem ipsum, dolor sit amet consectetur adipisicing elit. Distinctio atque quis sunt sequi ullam rem assumenda quaerat explicabo cupiditate! Corrupti fugiat distinctio eos repellendus itaque. Dolore velit saepe porro eius! </StepDescription>
            <StepDescription>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aspernatur, rerum eum repellat cupiditate eaque consequatur maxime, accusantium explicabo atque incidunt quas perspiciatis facilis voluptates illum? Nulla odio labore vel. Expedita.</StepDescription>

            
        </StepMainDiv>
    );
};

export default StepOne;