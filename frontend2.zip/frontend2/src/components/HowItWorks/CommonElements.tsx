import { Text } from "@nextui-org/react";
import styled from "styled-components";

export const StepCounter= styled.div`
font-size: 20px;
font-weight: 700;
background-color:black;
color:white;
width: 40px;
height: 40px;
border-radius:50%;
display:flex;
justify-content:center;
align-items:center;
`;

export const StepMainDiv = styled.div`
display:flex;
flex-direction:column;
justify-content:center;
align-items:left;
`
export const StepTitle = styled(Text)`
font-size: 20px;
font-weight:600;
margin:12px 0px;
`
export const StepDescription = styled(Text)`
color:#737373;
font-size:14px;
font-weight:400;
margin-bottom:20px;
`
export const SubTitle = styled.span`
color:black;
font-size:14px;
font-weight:700;
`