import { Container } from '@nextui-org/react';
import React from 'react';
import { useIsMobile, useIsTablet } from '@/hooks/useMediaQuery';

const VisualRepThree = ({ bg, src }: { bg: string, src: string }) => {
    const isMoblie = useIsMobile();
    const isTablet = useIsTablet();
    return (
        <Container fluid
            css={{
                bg: bg, jc: 'center',
                ai: 'center', display: 'flex',
                width: '100%',
                borderRadius: '32px',
                boxSizing: 'content-box',
                h:(isMoblie)?'200px': '400px',
            }}>
            <img src={src} alt='step' style={{boxSizing:'border-box',width:'70%',borderRadius:'10px'}} />
        </Container>
    );
};

export default VisualRepThree;