import React from 'react';
import { StepCounter, StepDescription, StepMainDiv, StepTitle } from './CommonElements';

const StepThree = () => {
    //TODO: need to change the contents
    return (
        <StepMainDiv>
            <StepCounter>3</StepCounter>
            <StepTitle>Lorem ipsum dolor</StepTitle>
            <StepDescription>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos itaque omnis quaerat quas temporibus doloremque repellat at earum minima sit tempora, consectetur sed aspernatur rem animi quidem voluptatibus vel architecto!</StepDescription>

            
        </StepMainDiv>
    );
};

export default StepThree;