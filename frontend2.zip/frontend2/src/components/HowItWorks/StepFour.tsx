import React from 'react';
import { StepCounter, StepDescription, StepMainDiv, StepTitle, SubTitle } from './CommonElements';

const StepFour = () => {
    //TODO: need to change the contents
    return (
        <StepMainDiv>
        <StepCounter>4</StepCounter>
        <StepTitle>Lorem ipsum dolor sit amet{/** TODO: need to change  */}</StepTitle>
        <StepDescription>Guide customers toward making a move with notifications and messages. Just like mobile apps, once a customer has your mobile wallet card, the possibilities for personalized communication are pretty much endless.</StepDescription>
        <StepDescription>Here are three direct ways to engage your audience:</StepDescription>
        <StepDescription><SubTitle>Message –</SubTitle> shoot your customer a direct message triggered by a business rule or some other event.</StepDescription>
        <StepDescription><SubTitle>Location –</SubTitle> send a notification when they're near a relevant spot, either through GPS    or beacons.</StepDescription>
        <StepDescription><SubTitle>Time –</SubTitle> give them a nudge when their offer is about to expire or let event-goers know it's showtime.</StepDescription>
        <StepDescription>However you decide to reach out, mobile wallets are a powerful way to engage with your customers at the moment.</StepDescription>
    </StepMainDiv>
    );
};

export default StepFour;