import { useIsMobile, useIsTablet } from '@/hooks/useMediaQuery';
import { Container } from '@nextui-org/react';
import React from 'react';

const VisualRepOne = ({ bg, src }: { bg: string, src: string }) => {
    const isMoblie = useIsMobile();
    const isTablet = useIsTablet();
    return (
        <Container fluid
            css={{
                bg: bg, jc: 'center',
                ai: 'center', display: 'flex',
                width: '100%',
                borderRadius: '32px',
                boxSizing: 'content-box',
                h:(isMoblie)?'200px': '400px',
            }}>
            <img src={src} alt='step' 
            style={{boxSizing:'border-box',
            width:'100%',borderRadius:'10px',
            position:'relative',left:(isMoblie||isTablet)?'0px':'70px',
            boxShadow: '0px 24px 50px -12px rgba(45, 54, 67, 0.12)',

            }} />
        </Container>
    );
};

export default VisualRepOne;