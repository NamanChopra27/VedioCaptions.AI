"use client";
import { Container, Spacer } from "@nextui-org/react";

export default function CommonPadding({ children, gap = 2, css = {} }: any) {
  return (
    <Container gap={gap} css={css}>
      <Spacer y={1} />
      {children}
      <Spacer y={1} />
    </Container>
  );
}
