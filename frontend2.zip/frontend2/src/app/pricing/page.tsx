'use client'
import PriceCard from '@/components/PriceCard/PriceCard';
import { CONSTS } from '@/constants';
import { Text } from '@nextui-org/react';
import React from 'react';

const page = () => {

const priceData=[
    {title:'Basic',border:'gray',amount:'$10',description:'Ideal if your are just starting in content creation',
    features:['Credits: 20 videos/month','Upload: 200MB/video','Download speed: Normal','Video length: 90s max',]},
    {title:'Pro',border:CONSTS.BRAND_COLORS.PRIMARY,amount:'$30',description:'Skyrocket your audience and increase retention',
    features:['Credits: Unlimited videos','Upload: 400MB/video','Download speed: Fast',
    'Video length: 180s max','AI-Powered auto description with hashtags']},
]

    return (
        <div>
            <Text h1 css={{ justifyContent: 'center',display:'flex',gap:'10px' }}>Start making your Captions <Text css={{textDecoration:'underline',color:CONSTS.BRAND_COLORS.PRIMARY}}>amazing, today.</Text></Text>
            <Text css={{ textAlign: 'center', fontWeight: '$light', fontSize: '24px', color: '$gray700' }}>No hidden fees. Cancel anytime.</Text>
      <div style={{display:'flex',justifyContent:'center',gap:'20px',margin:'auto',marginTop:'60px'}}>

       {
           priceData.map((data,index)=>{
               return <PriceCard key={index}  pricing={data} />
            })
        }
        </div>
        </div>
    );
};

export default page;