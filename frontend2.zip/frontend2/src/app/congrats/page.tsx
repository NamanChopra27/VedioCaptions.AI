"use client";
import { Button, Container, Image, Text } from "@nextui-org/react";
import React from "react";
import { CONSTS } from "../../constants";
import { useCallback } from "react";
import type { Container as PContainer, Engine } from "tsparticles-engine";
import Particles from "react-particles";
import { loadFull } from "tsparticles";
import { useRouter } from "next/navigation";

const Particle = () => {
  const particlesInit = useCallback(async (engine: Engine) => {
    console.log(engine);

    // you can initialize the tsParticles instance (engine) here, adding custom shapes or presets
    // this loads the tsparticles package bundle, it's the easiest method for getting everything ready
    // starting from v2 you can add only the features you need reducing the bundle size
    await loadFull(engine);
  }, []);

  const particlesLoaded = useCallback(
    async (container: PContainer | undefined) => {
      await console.log(container);
    },
    []
  );
  return (
    <Particles
      id="tsparticles"
      init={particlesInit}
      loaded={particlesLoaded}
      options={{
        background: {
          color: {
            value: "transparent",
          },
        },
        fullScreen: {
          zIndex: 1,
        },
        emitters: {
          position: {
            x: 50,
            y: 100,
          },
          rate: {
            quantity: 5,
            delay: 0.15,
          },
        },
        particles: {
          color: {
            value: ["#1E00FF", "#FF0061", "#E1FF00", "#00FF9E"],
          },
          move: {
            decay: 0.05,
            direction: "top",
            enable: true,
            gravity: {
              enable: true,
            },
            outModes: {
              top: "none",
              default: "destroy",
            },
            speed: {
              min: 50,
              max: 100,
            },
          },
          number: {
            value: 0,
          },
          opacity: {
            value: 1,
          },
          rotate: {
            value: {
              min: 0,
              max: 360,
            },
            direction: "random",
            animation: {
              enable: true,
              speed: 30,
            },
          },
          tilt: {
            direction: "random",
            enable: true,
            value: {
              min: 0,
              max: 360,
            },
            animation: {
              enable: true,
              speed: 30,
            },
          },
          size: {
            value: 3,
            animation: {
              enable: true,
              startValue: "min",
              count: 1,
              speed: 16,
              sync: true,
            },
          },
          roll: {
            darken: {
              enable: true,
              value: 25,
            },
            enlighten: {
              enable: true,
              value: 25,
            },
            enable: true,
            speed: {
              min: 5,
              max: 15,
            },
          },
          wobble: {
            distance: 30,
            enable: true,
            speed: {
              min: -7,
              max: 7,
            },
          },
          shape: {
            type: ["circle", "square", "triangle", "polygon"],
            options: {
              polygon: [
                {
                  sides: 5,
                },
                {
                  sides: 6,
                },
              ],
            },
          },
        },
        responsive: [
          {
            maxWidth: 1024,
            options: {
              particles: {
                move: {
                  speed: {
                    min: 33,
                    max: 66,
                  },
                },
              },
            },
          },
        ],
      }}
    />
  );
};

const Congrats = () => {
  const router = useRouter();
  const backtoHome = () => {
    router.push("/");
  };

  return (
    <div
      style={{
        margin: "0px",
        padding: "0px",
        background: `linear-gradient(359.45deg, ${CONSTS.BRAND_COLORS.PRIMARY} 0.49%, #2CD9FF 99.54%)`,
        width: "100%",
        height: "100vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <Particle />
      <Container
        css={{
          p: "16px",
          border: "none",
          w: "400px",
          borderRadius: "10px",
        }}
      >
        <Container
          css={{
            p: "32px",
            background: "White",
            borderRadius: "10px",
            textAlign: "center",
            display: "block",
          }}
        >
          <Text h2 css={{ mb: "20px" }}>
            Congrats
          </Text>
          <Text h3 color="#475467">
            We are processing your video
          </Text>
          <Text css={{ my: "32px", color: "#475467" }}>
          we anticipate sending the processed video to the email address you have provided within approximately 10 hours
          </Text>
          <Button
            rounded
            onPress={backtoHome}
            css={{ m: "auto", background: CONSTS.BRAND_COLORS.PRIMARY }}
          >
            Take me to Home Page
          </Button>
        </Container>
      </Container>
    </div>
  );
};

export default Congrats;
