import EditTabView from '@/components/EditTabView/EditTabView';
import React from 'react';

const page = () => {

    return (
        <div style={{marginTop:'20px'}}>
            <EditTabView />
        </div>
    );
};

export default page;