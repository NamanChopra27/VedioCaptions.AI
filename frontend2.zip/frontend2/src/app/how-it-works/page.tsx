'use client';
import StepFour from '@/components/HowItWorks/StepFour';
import StepOne from '@/components/HowItWorks/StepOne';
import StepThree from '@/components/HowItWorks/StepThree';
import StepTwo from '@/components/HowItWorks/StepTwo';
import VisualRepFour from '@/components/HowItWorks/VisualRepFour';
import VisualRepOne from '@/components/HowItWorks/VisualRepOne';
import VisualRepThree from '@/components/HowItWorks/VisualRepThree';
import VisualRepTwo from '@/components/HowItWorks/VisualRepTwo';
import { CONSTS } from '@/constants';
import { useIsTablet,useIsMobile } from '@/hooks/useMediaQuery';
import { Button, Text } from '@nextui-org/react';
import { useRouter } from 'next/navigation';
import React from 'react';
import styled from 'styled-components';




const GridContainer = styled.div<{ isMobile: boolean, isTablet: boolean }>`
display:grid;
column-gap:100px;
row-gap:10px;
padding:${(props) => ((props.isMobile || props.isTablet) ? '0px 10px' : '0px 60px')};
grid-template-columns:${(props) => ((props.isMobile || props.isTablet) ? 'repeat(3, 1fr)' : 'repeat(6, 1fr)')} ;
grid-auto-rows:${(props) => ((props.isMobile) ? 'minmax(200px, auto)' : props.isTablet ? 'minmax(400px,auto)' : `minmax(500px, auto)`)};
grid-template-areas:${(props) => ((props.isMobile || props.isTablet) ?
    `"img1 img1 img1"
"des1 des1 des1"
"img2 img2 img2"
"des2 des2 des2"
"img3 img3 img3"
"des3 des3 des3"
"img4 img4 img4"
"des4 des4 des4"
;`:
    `"img1 img1 img1 des1 des1 des1"
"des2 des2 des2 img2 img2 img2"
"img3 img3 img3 des3 des3 des3"
"des4 des4 des4 img4 img4 img4"
;`
  )};

.imgGrid {
  padding:10px;

}

.desGrid {
  padding:10px 80px 10px 10px;

  @media (max-width: 480px) {
         padding-right:10px;
      }
}
.allGrid {
  justify-content:center;
  align-items:center;
  display:flex;
  flex-direction:column;
}

.img1 {
    grid-area: img1;
  };
  .des1 {
    grid-area: des1;
  };
  
.img2 {
    grid-area: img2;
  };
  .des2 {
    grid-area: des2;
  };
  
.img3 {
    grid-area: img3;
  };
  .des3 {
    grid-area: des3;
  };
  
.img4 {
    grid-area: img4;
  };
  .des4 {
    grid-area: des4;
  };
 /* .cta{
    grid-area:cta;
    height:50px;
 }  */

`;





const HowItWroks = () => {
  const isMoblie = useIsMobile();
  const isTablet = useIsTablet();
  const router=useRouter();
  //TODO: need to change the  src of the VisualReps based on the prouct images
  return (
    <div>
      <Text h2 css={{ textAlign: 'center', mb: '50px', mt: '20px' }}>How It Works</Text>
      <GridContainer isMobile={isMoblie} isTablet={isTablet}>
        <div className="img1 imgGrid allGrid"><VisualRepOne src={'/assets/howItWroks/home.png'} bg={'#FBF0FF'} /></div>
        <div className="des1 desGrid allGrid"><StepOne /></div>
        <div className="img2 imgGrid allGrid"><VisualRepTwo src={'/assets/howItWroks/platforms.png'} bg={'#F0FFF3'} /></div>
        <div className="des2 desGrid allGrid"><StepTwo /></div>
        <div className="img3 imgGrid allGrid"><VisualRepThree src={'/assets/howItWroks/update.png'} bg={'#FFF0F0'} /></div>
        <div className="des3 desGrid allGrid"><StepThree /></div>
        <div className="img4 imgGrid allGrid"><VisualRepFour src={'/assets/howItWroks/notification.png'} bg={'#FFF5F0'} /></div>
        <div className="des4 desGrid allGrid"><StepFour /></div>
      </GridContainer>
          <Button css={{ bg: CONSTS.BRAND_COLORS.PRIMARY, ml: '70px' }}
          onPress={()=>router.push('/')}
          >Start Creating Card{/** Change the CTA */}</Button>
    </div>
  );
};

export default HowItWroks;