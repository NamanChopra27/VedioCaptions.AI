"use client";
import CommonPadding from "@/components/CommonPadding/CommonPadding";
import { Collapse, Text } from "@nextui-org/react";
import { usePathname, useSearchParams } from "next/navigation";
import React from "react";
import { styled } from "styled-components";

const BannerText = styled(Text)`
  background-color: #f1f3f5;
  padding: 2%;
  border-radius: 10px;
`;
const CommonWidth = styled.div`
  width: auto;
  @media only screen and (max-width: 768px) {
    width: 90%;
  }
`;

function page() {
  const searchParams = useSearchParams();
  const faqId = searchParams.get("id");

  console.log(faqId);

  //TODO: need to add product specific faqs
  return (
    <CommonWidth>
      <CommonPadding>
        <Text h2 css={{ marginBottom: "" }}>
          Frequently Asked Questions
        </Text>
        <div style={{ marginTop: "25px" }}>
          <Text b size={24} css={{ marginTop: "25px" }}>
            • General{" "}
          </Text>
          <Collapse.Group>
            <Collapse
              expanded={faqId === "How to use this Videocaptionsai?"}
              title="How to use this Videocaptionsai?"
            >
              <BannerText>{/** TODO: need to change content */}
                Lorem ipsum dolor sit amet consectetur adipisicing elit.
                 Doloremque sit quaerat neque quasi vitae tempore accusamus sed id in voluptates, 
                 voluptatum laborum, non molestias nobis, cum velit distinctio asperiores. Nam!
              </BannerText>
            </Collapse>{" "}
          
          </Collapse.Group>
        </div>

        <div style={{ marginTop: "25px" }}>
          <Text b size={24} css={{ marginTop: "25px" }}>
            • Billings
          </Text>

          <Collapse.Group>
            <Collapse
              expanded={faqId === "Do mobile wallet cards work offline?"}
              title="Do mobile wallet cards work offline?"
            >
              <BannerText>
                Yes, mobile wallet cards work offline once they've been saved to
                a customer's mobile wallet app. Customers can access and use the
                cards without an internet connection, making them convenient for
                on-the-go use.
              </BannerText>
            </Collapse>

            <Collapse
              expanded={faqId === "Can I cancel anytime?"}
              title="Can I cancel anytime?"
            >
              <BannerText>
                Yes, you can cancel your subscription at any time in your
                dashboard or by contacting support. When you cancel, your
                account will remain active untill the end of the billing cycle.
                Please contact support if you wish to delete your account.
              </BannerText>
            </Collapse>
            <Collapse
              expanded={faqId === "Can I get a refund?"}
              title="Can I get a refund?"
            >
              <BannerText>
                Paid Subscription fees are non-refundable. Certain refund
                requests for subscriptions may be considered by the company on a
                case-by-case basis and granted at the sole discretion of the
                company. If you are unhappy with the service for any reason,
                contact us or email us at support@exponentialhost.com, and we
                will work with you to make it right.
              </BannerText>
            </Collapse>
            <Collapse
              expanded={faqId === "Can I change my card details?"}
              title="Can I change my card details?"
            >
              <BannerText>
                You woul need to first cancel your subscription . And then buy
                subscription second time with different card
              </BannerText>
            </Collapse>
          </Collapse.Group>
        </div>
      </CommonPadding>
    
    </CommonWidth>
  );
}

export default page;
