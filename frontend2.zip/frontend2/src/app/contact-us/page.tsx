"use client";
import { Card, Container, Text, Grid, Spacer, Row } from "@nextui-org/react";
import styled from "styled-components";
import { useState, useEffect } from "react";

const AboutUsCard = styled(Card)`
  padding: 0px 0px;
`;
const ContactUsDiv = styled.div`
  `

const GoogleFormUrl =
  "https://docs.google.com/forms/d/e/1FAIpQLScxyDH4vu58Mmn6GaxQShx4LgoCbiLsSZhfPuv4We5nQBQMkA/viewform?embedded=true";

const ContactCard = styled(Card)`
  padding: 20px 14px;

  .companyDetails {
    text-align: center;
    border-bottom: 1px solid;
  }
  .expoLogo {
  }
`;
const AboutUs = () => {

  const [isready, setIsReady] = useState(false);

  useEffect(() => {
    setIsReady(true);
  }, []);

  const contactInfo: any = {
    email: { value: "support@exponentialhost.com", icon: "E" },
  };

//TODO: need to change product specific details

  return (
    <>
      <head>
        <title>VideoCaptionsAI | Contact Us</title>
      </head>
      {isready && (
        <>
        <ContactUsDiv>
          <Container gap={0}>
            <Grid.Container>
              <Grid xs={12}>
                <div
                  style={{
                    width: "100%",
                  }}
                >
                  <iframe
                    id="contactform"
                    src={GoogleFormUrl}
                    width="100%"
                    height="900"
                    frameBorder="0"
                  >
                    Loading…
                  </iframe>
                </div>
              </Grid>
              <Grid
                xs={12}
                css={{ fd: "column" }}
                className="AboutCard"
                justify="flex-start"
                alignItems="center"
              >
                <ContactCard
                  className="companyCard"
                  css={{
                    py: "$4",
                    bgColor: "rgb(224 224 224 / 19%)",
                  }}
                  variant="flat"
                >
                  <Card.Body css={{ px: "$14",paddingLeft:"10px" }}>
                    <Grid.Container gap={1}>
                      {/* Google map snippet */}
                      <Grid
                        xs={12}
                        md={6}
                        lg={12}
                        css={{ display: "flex", fd: "column" }}
                      >
                        <div className="companyDetails">
                          <div className="expoLogo">
                            <Text
                              h3
                              weight="extrabold"
                              css={
                                {
                                  /* ta: 'center' */
                                }
                              }
                            >
                              Enrich Hosting Pvt Ltd.
                            </Text>
                          </div>
                        </div>
                        <Spacer y={1} />
                        {Object.keys(contactInfo).map(
                          (keyOfItem) =>
                            contactInfo[keyOfItem].value && (
                              <Row
                                css={{ ai: "flex-start", mb: "$2" }}
                                key={keyOfItem}
                              >
                               
                                <div>
                                  <Text size="small" css={{ lh: "$md" }}>
                                    {keyOfItem}
                                  </Text>
                                  <Text h5 className={`value__${keyOfItem}`}>
                                    {keyOfItem === "email" ? (
                                      <a
                                        href={`mailto:${contactInfo[keyOfItem].value}`}
                                      >
                                        {contactInfo[keyOfItem].value}
                                      </a>
                                    ) : (
                                      contactInfo[keyOfItem].value
                                    )}
                                  </Text>
                                </div>
                              </Row>
                            )
                        )}
                      </Grid>
                      
                    </Grid.Container>
                  </Card.Body>
                </ContactCard>
              </Grid>
            </Grid.Container>
          </Container>
          </ContactUsDiv>
          <style>
        {`
          @media (max-width: 768px) {
            #contactform {
              height: 950px; /* Adjust the height as needed */
            }
            #gmap_canvas{
              width: 90%;
            }
          }
          @media (max-width: 480px) {
            #contactform {
              height: 1030px; /* Adjust the height as needed */
            }
          }
        `}
      </style>
        </>
      )}
    </>
  );
};
export default AboutUs;
