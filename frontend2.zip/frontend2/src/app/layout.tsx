'use client'
import { SessionProvider } from "next-auth/react";
import React, { useEffect, useState } from "react";
import { Poppins } from "next/font/google";
import { validateAccessToken } from "@/apis/userApis";
import { getCookie } from "@/utils/cookieUtil";
const poppins = Poppins({
  subsets: ["latin"],
  weight: "500",
});
import Header from "@/components/Header/Header";
import Footer from "@/components/Footer/Footer";
import LoadingScreen from "@/components/EmptyStates/LoadingScreen";
import Body from "@/components/Body/Body";
import Script from "next/script";
import { CONSTS } from "@/constants";

interface RootLayoutProps {
  children: React.ReactNode;
  pageProps: any;
}

// export const metadaMeta: Metadata = {
//   title: 'GetMagicLink | Create Custom Passes and Cards for Apple Wallet and Google Wallet',
//   description: 'Generate personalized membership cards, event tickets, gift cards, and special offers with GetMagicLink. Easily create, customize, and add passes to Apple Wallet and Google Wallet. Seamlessly redirect users based on wallet compatibility for a seamless user experience.',
//   icons: {
//     icon: '/magic.png',
//   },
// }


export default function RootLayout({ children, pageProps }: RootLayoutProps) {
  const [loading, setIsLoading] = useState(true);
  const validateLoginCookie = async (accessToken: any, tokenType: any) => {
    const body: any = await validateAccessToken(accessToken, tokenType);
    console.log("validating accessToken....");
    const isvalid = body.status;
    if (!isvalid) {
      console.log("accessToken expired please login again");
    } else {
      console.log("accessToken was valid");
    }
  };

  useEffect(() => {
    const validateAccessToken = async () => {
      try {
        let accessToken = getCookie("accessToken");

        await validateLoginCookie(accessToken, "accessToken");
      } catch (error) {
        console.error(error);
      } finally {
        setIsLoading(false);
      }
    };
    validateAccessToken();
  }, []);

  return (
   
      <html lang="en">
         <Script
        strategy="lazyOnload"
        src={`https://www.googletagmanager.com/gtag/js?id=${process.env.NEXT_PUBLIC_GOOGLE_ANALYTICS}`}
      />

      <Script strategy="lazyOnload">
        {`
                    window.dataLayer = window.dataLayer || [];
                    function gtag(){dataLayer.push(arguments);}
                    gtag('js', new Date());
                    gtag('config', '${process.env.NEXT_PUBLIC_GOOGLE_ANALYTICS}', {
                    page_path: window.location.pathname,
                    });
                `}
      </Script>
        <head>

          <title>
            {CONSTS.MAIN_TITLE}
          </title>
          <meta
            name="description"
            content={CONSTS.MAIN_DESCRIPTION}
          />
          <link rel="icon" href={CONSTS.TITLE_LOGO_PATH} />
        </head>
        <SessionProvider session={pageProps?.session} >
        <body className={poppins.className} style={{ margin: "0", padding: "0", }}>
          {loading ? (
            <LoadingScreen />
          ) : (
            <>
              <Header />
              <Body>
                {children}
              </Body>
              <Footer />
            </>
          )}
        </body>
        </SessionProvider>
      </html>
   
  );
};
