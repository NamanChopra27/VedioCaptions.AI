"use client";
import {
  activeSubscription,
  getAllTransactions,
  getPreviousSubscription,
  stripeCheckout,
  stripeValidate,
} from "@/apis/paymentsApis";
import BillingsTable from "../../components/BillingsTable/BillingsTable";
import Header from "@/components/Header/Header";
import { Button, Text, Loading, Container } from "@nextui-org/react";
import React, { useEffect, useState } from "react";
import { styled } from "styled-components";
import toast, { Toaster } from "react-hot-toast";
import { useSearchParams, useRouter } from "next/navigation";
import GreenTick from "@/icons/GreenTick";
import SubscriptionDetails from "@/components/SubscriptionDetails/SubscriptionDetails";
import Footer from "@/components/Footer/Footer";
import LoadingScreen from "@/components/EmptyStates/LoadingScreen";

const MainDiv = styled.div`
  margin-left: 90px;
  @media only screen and (max-width: 768px) {
   margin:10px;
  }
`;

const BillingsTablediv = styled.div`
  display: flex;
  flex-direction: column;
  gap: 62px;
  margin-top: 40px;
`;

const SubscriptionStatus = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #ffe8e8;
  height: 64px;
  gap: 40px;
`;
const SubscriptionStatusText = styled.div`
  margin: 0;
  color: #f15555;
  font-size: 16px;
  font-weight: 400;
  line-height: 20px;
`;

const FirstPurchaseBox = styled.div`
  display: inline-flex;
  padding: 32px;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  gap: 48px;
  border-radius: 16px;
  border: 1px solid #f9f9f9;
  background: #fff;
  box-shadow: 0px 8px 11px -4px rgba(45, 54, 67, 0.04),
    0px 20px 24px -4px rgba(45, 54, 67, 0.04);
`;
const PurchaseBoxText = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  color: #5d6368;
`;
const PurchaseBoxDivider = styled.div`
  border: none;
  border-top: 1px solid var(--main-linke, #e5e7eb);
`;
const page = () => {
  const [ready, isReady] = useState(false);
  const [loading, setloading] = useState(true);
  const [transactionLoading, setTransactionloading] = useState(true);
  const [subscriptionStatus, setSubscriptionStatus] = useState(null);
  const [subscriptiondata, setSubscriptiondata] = useState(null);
  const [firstSubscription, setFirstSubscription] = useState(false);
  const [transactions, setTransactions] = useState(null);
  const searchParams = useSearchParams();

  useEffect(() => {
    (async () => {
      try {
        const response = await activeSubscription();
        setSubscriptiondata(response?.data);
        if (response?.data?.status) {
          setSubscriptionStatus(response?.data?.status);
        }
        setloading(false);
      } catch (error: any) {
        if (!error.status) {
          try {
            const response = await getPreviousSubscription();
          } catch (error: any) {
            if (!error?.status) {
              console.log("handle error state");
              setFirstSubscription(true);
            }
          }
        }
        console.error(error);
        setloading(false);
      }
    })();

    (async () => {
      try {
        const response = await getAllTransactions();
        setTransactions(response?.data);
      } catch (error) {
        console.error(error);
      } finally {
        setTransactionloading(false);
      }
    })();
  }, []);

  useEffect(() => {
    if (
      (searchParams.get("canceled") || searchParams.get("success")) &&
      ready
    ) {
      (async () => {
        try {
          const success = searchParams.get("success");
          const canceled = searchParams.get("canceled");
          const session_id = searchParams.get("session_id");
          console.log(
            "success:" + success,
            "canceled" + canceled,
            "session_id:" + session_id
          );
          const res = await stripeValidate({ success, canceled, session_id });
          toast("Payment Success", {
            position: "top-right",
            style: {
              width: "200px",
              borderRadius: "16px",
              fontSize: "16px",
              color: "#016A1C",
              backgroundColor: "#E1FCDE",
            },
          });
        } catch (error) {
          
          toast("Payment Failed", {
            position: "top-right",
            style: {
              width: "15vw",
              borderRadius: "16px",
              fontSize: "16px",
              color: "#B1000F",
              backgroundColor: "#FFD4D8",
            },
          }
          );
          console.error(error);
        }
        finally{
          //removing params
          window.history.replaceState({}, document.title, window.location.pathname);
        }
      })();
    }
  }, [ready]);

  useEffect(() => {
    isReady(true);
  }, []);
  const handleClick = async () => {
    try {
      const res = await stripeCheckout({path: "billings"});
      //@ts-ignore
      window.location.href = res.url;
    } catch (error) {
      toast("Payment Failed", {
        position: "top-right",
        style: {
          width: "15vw",
          borderRadius: "16px",
          fontSize: "16px",
          color: "#B1000F",
          backgroundColor: "#FFD4D8",
        },
      });
      console.error("Payment false:", error);
    }
  };
  return (
    <>
      {ready && !loading ? (
        <>
          {!subscriptionStatus && !firstSubscription && !loading && (
            <>
              <SubscriptionStatus>
                <SubscriptionStatusText>
                  Your Subscription has ended Renew Subscription today
                </SubscriptionStatusText>
                <SubscriptionStatusText
                  onClick={handleClick}
                  style={{
                    color: "#000",
                    cursor: "pointer",
                    textDecoration: "underline",
                  }}
                >
                  {" "}
                  Renew Subscription
                </SubscriptionStatusText>
              </SubscriptionStatus>
            </>
          )}

          {subscriptionStatus === "trialing" && !loading && (
            <>
              <SubscriptionStatus style={{ background: "#fef0d3" }}>
                <SubscriptionStatusText style={{ color: "#FA0" }}>
                  You are on trial period
                </SubscriptionStatusText>
              </SubscriptionStatus>
            </>
          )}
          <MainDiv>
            {firstSubscription && (
              <>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    height:"80vh",
                  }}
                >
                  <FirstPurchaseBox>
                    <div style={{ width: "280px" }}>
                      <div style={{ display: "flex", alignItems: "baseline" }}>
                        <Text size={32} b>
                          $14 {/** TODO: need to change the product pricing*/}
                        </Text>
                        &nbsp;
                        <Text style={{ color: "#94A3B8" }}>Per Month</Text>
                      </div>
                      <PurchaseBoxDivider></PurchaseBoxDivider>
                      <div
                        style={{
                          display: "flex",
                          flexDirection: "column",
                          alignItems: "flex-start",
                          marginTop: "20px",
                          gap: "10px",
                        }}
                      >
                       
                        <PurchaseBoxText>
                          <GreenTick />
                          &nbsp; No WaterMark
                        </PurchaseBoxText>
                        <PurchaseBoxText>
                          <GreenTick /> &nbsp; Edit Multiple Pass
                        </PurchaseBoxText>
                        <PurchaseBoxText>
                          <GreenTick /> &nbsp; View Pass Usage Stats
                        </PurchaseBoxText>
                      </div>
                    </div>
                    <Button
                      onPress={handleClick}
                      css={{
                        w: "20vw",
                        borderRadius: "10px",
                        background: "#6359FD",
                      }}
                    >
                      Subscribe
                    </Button>
                  </FirstPurchaseBox>
                </div>
              </>
            )}



            {!firstSubscription && (
              <>
                <BillingsTablediv>
            <SubscriptionDetails subscriptiondata={subscriptiondata} />

              <BillingsTable
                    transactions={transactions}
                    loading={transactionLoading}
                  /> 
                </BillingsTablediv>
              </>
            )}
          </MainDiv>

          <Toaster />
        </>
      ) : (
        <LoadingScreen/>
      )}
    </>
  );
};

export default page;
