"use client";
import Header from "@/components/Header/Header";
import React from "react";
import { useEffect, useState } from "react";
import CommonPadding from "@/components/CommonPadding/CommonPadding";
import Footer from "@/components/Footer/Footer";
import { styled } from "styled-components";
import Head from "next/head";

const CommonWidth=styled.div`
 @media only screen and (max-width: 768px) {
    width: 80vw;
  }
 
  @media only screen and (max-width: 512px) {
    width: 85vw;
  }
 
`

const page = () => {
  const [isready, setIsReady] = useState(false);

  useEffect(() => {
    setIsReady(true);
  }, []);

  //TODO: need to change the Product specific details like name
  return (
    <>
      {isready && (
        <>
          <head>
            <title>VideoCaptionsAI | Terms</title>
          </head>
          <CommonWidth>
          <CommonPadding>
            
            <div>
              <h3> Terms of use </h3>
              <p> Last updated: 10th Sept, 2023 </p>
              <br />
            </div>
            <div>
              <h2>Welcome to VideoCaptionsAI</h2>
              <br></br>
              <p>
                These terms of service (these “Terms”) govern the use of our
                network and other products and services
                (collectively, the “Service”) provided by Enrich Hosting Pvt
                Ltd. (“getmagiclink”, “us,” or “we”) via
                getmagiclink.com (the “Site” or “Sites”).
              </p>
              <br />
              <p>
                By using the Service, registering for it, or providing access to
                any apps via the Service, you agree to be
                bound by all of the terms and conditions of these Terms.
              </p>
              <br />
              <p>
                These Terms apply to both coupon creators(individuals or
                entities that create coupons) and coupon
                Consumers (individuals or entities that obtain access to coupons
                via the Service).
              </p> 
              <br />
              <p>
                The “Effective Date” of these Terms is the date you first access
                the Service.
              </p>
              <br />
              <p>
                We reserve the right to change or modify any of the terms and
                conditions contained in these Terms at any time and in our sole
                discretion. We will provide notice of any changes, which may be
                sent via email, posted on the Site, or through other means
                determined by us. Any changes or modifications will be effective
                7 days after notice is given. You are responsible for regularly
                reviewing these Terms to ensure you understand and agree to the
                terms that apply to your use of the Service.
              </p>
              <br />
              <h4>
                <strong>PRIVACY</strong>
              </h4>
              <p>
                For information about how we collect, use and share information
                about users of the Service, please see our{" "}
              </p>
              <section>
                <h3>SERVICE & REGISTRATION</h3>
                <h5>
                  <strong>Service</strong>
                </h5>
                <ul>
                  <li>
                    GetmagicLink operates an online portal to create coupons, deals, tickets, gift cards, loyalty cards, and even membership IDs. for google and apple wallet
                  </li>
                  <li>
                  GetmagicLink provides a click-thru URL, which will be used to save cards in there wallets
                  </li>
                  <li>
                  GetmagicLink provides metrics such as number of views,number of saves,number of removes,and save rate for individual as well as all cards created by the entity
                  </li>
                  <li>
                    By using the Service, you agree to be bound by the terms and
                    conditions outlined in these Terms.
                  </li>
                </ul>
                <br />
                <h5>
                  <strong>Registration</strong>
                </h5>
                <ul>
                  <li>
                    In order to access the Service, individuals/organizations must complete the registration forms provided on the Site.
                  </li>
                  <li>
                    You must provide accurate and up-to-date registration data,
                    maintain the security of your account password, and assume
                    all risks associated with unauthorized access.
                  </li>
                  <li>
                    You are solely responsible for safeguarding your passwords
                    and any activities or transactions related to your
                    GetMagicLink account or password.
                  </li>
                </ul>
                <br />
                <h5>
                  <strong> Rights</strong>
                </h5>
                <ul>
                  <li>
                    GetMagicLink is only responsible for providing the
                    GetMagicLink.com platform. 
                  </li>
                  <li>
                  Individuals/Organizations are responsible for all support and claims
                    related to their Coupons.
                  </li>
                  <li>
                  GetMagicLink reserves the right to review, screen, or
                    monitor links to Coupons Content at any time and
                    for any reason without notice.
                  </li>
                  <li>
                  GetMagicLink may remove any Coupon
                  </li>
                </ul>
                <br />
              </section>
              <br />
              
             
              <br />
              <section>
                <h3>Prohibited Use and Restrictions</h3>
                <p>
                  You are prohibited from using the Service for any unauthorized
                  or illegal activity, including but not limited to:
                </p>
                <ul>
                  <li>
                    Modifying, disclosing, altering, translating, or creating
                    derivative works of the Service or any components thereof
                    without the express permission of GetMagicLink.
                  </li>
                  <li>
                    Licensing, sublicensing, reselling, distributing, leasing,
                    renting, lending, transferring, assigning, or otherwise
                    disposing of the Service or any components thereof without
                    the express permission of Exponential.
                  </li>
                  <li>
                    Disassembling, decompiling, or reverse engineering the
                    software components of the Service.
                  </li>
                  <li>
                    Storing or transmitting infringing, libelous, or otherwise
                    unlawful or tortious material, or material in violation of
                    third-party privacy rights.
                  </li>
                  <li>
                    Storing or transmitting any viruses, software routines, or
                    other code designed to permit unauthorized access, disable,
                    erase, or otherwise harm software, hardware, or data, or to
                    perform any other harmful actions.
                  </li>
                  <li>
                    Copying, framing, or mirroring any part or content of the
                    Service.
                  </li>
                  <li>
                    Building a competitive product or service, or copying any
                    features or functions of the Service.
                  </li>
                  <li>
                    Interfering with or disrupting the integrity or performance
                    of the Service.
                  </li>
                  <li>
                    Attempting to gain unauthorized access to the Service or
                    related systems or networks.
                  </li>
                  <li>
                    Removing, altering, or obscuring any proprietary notices in
                    or on the Service, including copyright notices.
                  </li>
                  <li>
                    Causing or permitting any third-party to do any of the
                    foregoing.
                  </li>
                  <li>
                    Interfering in any manner with the enjoyment of the Service
                    by other users.
                  </li>
                  <li>
                    By using the Service, you agree to comply with all
                    applicable laws and regulations. GetMagicLink reserves
                    the right to terminate or restrict your access to the
                    Service if you engage in any prohibited or illegal activity.
                  </li>
                </ul>
                <br />
                <h5>
                  <strong>Suspension or Termination</strong>
                </h5>
                <ul>
                  <li>
                    GetMagicLink may suspend or terminate a user&lsquo;s
                    access to the service at any time and for any reason without
                    notice.
                  </li>
                  <li>
                    If a user&lsquo;s access is suspended or terminated, they
                    must stop accessing or using the Service immediately.
                  </li>
                  <li>
                    GetMagicLink may take legal action against a user for
                    continuing to use the service during suspension or after
                    termination.
                  </li>
                  <li>
                    These terms will remain enforceable against the user while
                    their license to access or use the Service is suspended and
                    after it is terminated.
                  </li>
                </ul>
                <br />
              </section>
              <br />
              <section>
                <h3>Disclaimer</h3>
                <p>
                  YOUR USE OF THE SERVICE IS AT YOUR SOLE RISK. THE SERVICE IS
                  PROVIDED ON AN “AS IS” AND “AS AVAILABLE” BASIS.
                  GetMagicLink DISCLAIMS ALL WARRANTIES AND REPRESENTATIONS
                  (EXPRESS OR IMPLIED, ORAL OR WRITTEN) WITH RESPECT TO THESE
                  TERMS, THE SERVICE, ANY OF THE APPS PROVIDED VIA THE SERVICE,
                  ANY API CONTENT/TERMS, ANY USER CONTENT, THE SITE (INCLUDING
                  ANY INFORMATION AND CONTENT MADE AVAILABLE VIA THE SITE AND
                  THE EXPONENENTIAL.HOST MATERIALS), THIRD-PARTY INFRASTRUCTURE
                  (AS DEFINED BELOW) AND THIRD-PARTY TRADEMARKS, WHETHER ALLEGED
                  TO ARISE BY OPERATION OF LAW, BY REASON OF CUSTOM OR USAGE IN
                  THE TRADE, BY COURSE OF DEALING OR OTHERWISE, INCLUDING ANY
                  WARRANTIES OF MERCHANTABILITY, FITNESS FOR ANY PURPOSE,
                  NON-INFRINGEMENT, AND CONDITION OF TITLE.
                </p>
                <br />
                <p>
                  TO THE FULLEST EXTENT PERMITTED BY APPLICABLE LAW,
                  GetMagicLink DOES NOT WARRANT, AND DISCLAIMS ALL LIABILITY
                  FOR (A) THE COMPLETENESS, ACCURACY, AVAILABILITY, TIMELINESS,
                  SECURITY, OR RELIABILITY OF THE SERVICE, ANY OF THE APIS
                  PROVIDED VIA THE SERVICE, ANY USER CONTENT, THE SITE
                  (INCLUDING ANY INFORMATION OR CONTENT MADE AVAILABLE VIA THE
                  SITE), OR THIRD-PARTY TRADEMARKS; (B) ANY HARM TO YOUR
                  COMPUTER SYSTEM, LOSS OF DATA, OR OTHER HARM THAT RESULTS FROM
                  YOUR ACCESS TO OR USE OF THE SERVICE AND ANY API MADE
                  AVAILABLE VIA THE SERVICE; (C) THE DELETION OF, OR THE FAILURE
                  TO STORE OR TRANSMIT, ANY USER CONTENT AND OTHER
                  COMMUNICATIONS MAINTAINED BY THE SERVICE; AND (D) WHETHER THE
                  SERVICE WILL MEET YOUR REQUIREMENTS OR BE AVAILABLE ON AN
                  UNINTERRUPTED, SECURE, OR ERROR-FREE BASIS.
                </p>
              </section>
              <br />
              <section>
                <h3>Indemnification</h3>
                <p>
                  You agree, at your sole expense, to defend, indemnify and hold
                  GetMagicLink (and its directors, officers, employees,
                  consultants and agents) harmless from and against any and all
                  actual or threatened suits, actions, proceedings (at law or in
                  equity), claims, damages, payments, deficiencies, fines,
                  judgments, settlements, liabilities, losses, costs and
                  expenses (including, but not limited to, reasonable attorneys’
                  fees, costs, penalties, interest and disbursements) for any
                  death, injury, property damage caused by, arising out of,
                  resulting from, attributable to or in any way incidental to
                  any of your conduct or any actual or alleged breach of any of
                  your obligations under these Terms (including, but not limited
                  to, any actual or alleged breach of any of your
                  representations or warranties as set forth in these Terms).
                </p>
              </section>
              <br />
              <section>
                <h3>Limitation of liability </h3>
                <p>
                  TO THE FULLEST EXTENT PERMITTED BY APPLICABLE LAW,
                  GetMagicLink WILL NOT BE LIABLE TO YOU OR ANY THIRD PARTY
                  FOR ANY INCIDENTAL, SPECIAL, INDIRECT, CONSEQUENTIAL,
                  EXEMPLARY, OR PUNITIVE DAMAGES WHATSOEVER, ARISING OUT OF OR
                  RELATED TO THESE TERMS, THE SERVICE, ANY OF THE APIS PROVIDED
                  VIA THE SERVICE, ANY API CONTENT/TERMS, ANY USER CONTENT, THE
                  SITE (INCLUDING ANY INFORMATION AND CONTENT MADE AVAILABLE VIA
                  THE SITE AND GetMagicLink MATERIALS), THIRD-PARTY
                  INFRASTRUCTURE OR THIRD-PARTY TRADEMARKS, HOWEVER CAUSED,
                  REGARDLESS OF THE THEORY OF LIABILITY (CONTRACT, WARRANTY,
                  TORT (INCLUDING NEGLIGENCE, WHETHER ACTIVE, PASSIVE OR
                  IMPUTED), PRODUCT LIABILITY, STRICT LIABILITY, OR OTHER
                  THEORY), EVEN IF GetMagicLink HAS BEEN ADVISED OF THE
                  POSSIBILITY OF SUCH DAMAGES.
                </p>
                <br />
                <p>
                  IN NO EVENT SHALL THE AGGREGATE LIABILITY OF GetMagicLink
                  ARISING OUT OF OR RELATED TO THESE TERMS, THE SERVICE, ANY OF
                  THE APIS PROVIDED VIA THE SERVICE, ANY API CONTENT/TERMS, ANY
                  USER CONTENT, THE SITE (INCLUDING ANY INFORMATION OR CONTENT
                  MADE AVAILABLE VIA THE SITE), THIRD-PARTY INFRASTRUCTURE OR
                  THIRD-PARTY TRADEMARKS EXCEED ONE HUNDRED U.S. DOLLARS (USD
                  $100.00).
                </p>
                <br />
                <p>
                  SOME STATES DO NOT ALLOW THE EXCLUSION OR LIMITATION OF
                  INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THIS LIMITATION MAY
                  NOT APPLY TO YOU.
                </p>
                <br />
                <p>
                  GetMagicLink reserves the right, but does not have the
                  obligation, to review, screen, or monitor any links to any
                  Apps or any App Content/Terms (as defined below) at any time
                  and for any reason without notice.
                </p>
              </section>
              <br />
              <section>
                <h3>Arbitration</h3>
                <p>
                  PLEASE READ THE FOLLOWING PARAGRAPHS CAREFULLY BECAUSE THEY
                  REQUIRE YOU TO ARBITRATE DISPUTES WITH GetMagicLink AND
                  LIMIT THE MANNER IN WHICH YOU CAN SEEK RELIEF FROM
                  GetMagicLink.
                </p>
                <br />
                <p>
                  In the event of any controversy or claim arising out of or
                  relating in any way to these Terms or the Service, you and
                  GetMagicLink agree to consult and negotiate with each
                  other and, recognizing your mutual interests, try to reach a
                  solution satisfactory to both parties. If we do not reach
                  settlement within a period of 60 days, then either of us may,
                  by notice to the other, demand mediation under the mediation
                  rules of the Indian Council of Arbitration (ICA) based in New
                  Delhi, India. We both give up our right to litigate our
                  disputes and may not proceed to arbitration without first
                  trying mediation, but you and GetMagicLink are NOT
                  required to arbitrate any dispute in which either party seeks
                  equitable and other relief from the alleged unlawful use of
                  copyrights, trademarks, trade names, logos, trade secrets or
                  patents. Except as otherwise required under applicable law,
                  you and GetMagicLink intend and agree: (a) not to assert
                  class action or representative action procedures and agree
                  that they will not apply in any arbitration involving the
                  other; (b) not to assert class action or representative action
                  claims against the other in arbitration or otherwise; and (c)
                  will only submit individual claims in arbitration and will not
                  seek to represent the interests of any other person or entity.
                </p>
                <br />
                <p>
                  If settlement is not reached within 60 days after service of a
                  written demand for mediation, any unresolved controversy or
                  claim will be resolved by arbitration in accordance with the
                  rules of the Indian Council of Arbitration (ICA) based in New
                  Delhi, India. The language of all proceedings and filings will
                  be English. The arbitrator will render a written opinion
                  including findings of fact and law and the award and/or
                  determination of the arbitrator will be binding on the
                  parties, and their respective administrators and assigns, and
                  will not be subject to appeal. Judgment may be entered upon
                  the award of the arbitrator in any court of competent
                  jurisdiction. The expenses of the arbitration will be shared
                  equally by the parties unless the arbitration determines that
                  the expenses will be otherwise assessed and the prevailing
                  party may be awarded its attorneys’ fees and expenses by the
                  arbitrator. It is the intent of the parties that, barring
                  extraordinary circumstances, arbitration proceedings will be
                  concluded within 90 days from the date the arbitrator is
                  appointed. The arbitrator may extend this time limit only if
                  failure to do so would unduly prejudice the rights of the
                  parties. Failure to adhere to this time limit will not
                  constitute a basis for challenging the award. Consistent with
                  the expedited nature of arbitration, pre-hearing information
                  exchange will be limited to the reasonable production of
                  relevant, non-privileged documents, carried out expeditiously.
                </p>
              </section>
              <br />
              <section>
                <h3>Miscellaneous</h3>
                <h5>
                  <strong>Feedback</strong>
                </h5>
                <ul>
                  <li>
                    Any suggestions, comments, or other feedback provided by you
                    to GetMagicLink with respect to the Service or
                    GetMagicLink will be considered non-confidential and
                    non-proprietary.
                  </li>
                  <li>
                    By providing Feedback to GetMagicLink, you grant
                    GetMagicLink a non-exclusive, worldwide, royalty-free,
                    irrevocable, sub-licensable, and transferable license to
                    use, copy, distribute, and disclose the Feedback in any
                    manner and for any purpose.
                  </li>
                </ul>
                <br />
                <h5>
                  <strong>Feedback</strong>
                </h5>
                <ul>
                  <li>
                    You are granted a limited, non-exclusive right to create a
                    text hyperlink to the Service for noncommercial purposes,
                    provided such link does not portray GetMagicLink or any
                    of its products and services in a false, misleading,
                    derogatory, or defamatory manner and that the linking site
                    does not contain any material that is offensive, illegal,
                    harassing, or otherwise objectionable.
                  </li>
                  <li>This limited right may be revoked at any time.</li>
                  <li>
                    GetMagicLink makes no claim or representation regarding,
                    and accepts no responsibility for, the quality, content,
                    nature, or reliability of third-party sites accessible by
                    link from the Service or Site.
                  </li>
                  <li>
                    GetMagicLink provides these links to you only as a
                    convenience, and the inclusion of any link does not imply
                    affiliation, endorsement, or adoption by GetMagicLink of
                    the corresponding site or any information contained in (or
                    made available via) that site.
                  </li>
                  <li>
                    When you leave the Site, GetMagicLink’s terms and
                    policies no longer govern.
                  </li>
                  <li>
                    You should review the applicable terms and policies,
                    including privacy and data-gathering practices, of any site
                    to which you navigate from the Site.
                  </li>
                </ul>
                <br />
                <h5>
                  <strong>Third-Party Advertising</strong>
                </h5>
                <ul>
                  <li>
                    GetMagicLink may run advertisements and promotions from
                    third parties through or in connection with the Service or
                    may provide information about or links to third-party
                    products or services.
                  </li>
                  <li>
                    Your dealings or correspondence with, or participation in
                    promotions of, any such third parties, and any terms,
                    conditions, warranties, or representations associated with
                    such dealings, correspondence, or promotions, are solely
                    between you and the applicable third party.
                  </li>
                  <li>
                    GetMagicLink is not responsible or liable for any loss
                    or damage of any sort incurred as the result of any such
                    dealings, correspondence, or promotions or as the result of
                    the presence of such advertisers or third-party information
                    made available through the Service.
                  </li>
                </ul>
                <br />

                <h5>
                  <strong>Independent Contractors</strong>
                </h5>
                <ul>
                  <li>
                    The parties will only have the relationship of independent
                    contractors.
                  </li>
                  <li>
                    Neither party will be considered an agent, franchisor,
                    franchise, employee, representative, owner, or partner of
                    the other party.
                  </li>
                  <li>
                    Neither party will have the authority to make any
                    representations or warranties on behalf of the other party
                    or to bind the other party in any way.
                  </li>
                </ul>
                <br />

                <h5>
                  <strong>Assignment</strong>
                </h5>
                <ul>
                  <li>
                    You may not assign, delegate, or transfer these Terms or any
                    rights without the prior written consent of
                    GetMagicLink.
                  </li>
                  <li>
                    Any attempted or purported assignment, delegation, or
                    transfer without consent will be null and void.
                  </li>
                  <li>
                    GetMagicLink may assign these Terms without your prior
                    written consent and the terms will be binding and inure to
                    the benefit of the assignees, transferees, and other
                    successors.
                  </li>
                </ul>
                <br />

                <h5>
                  <strong>Third-Party Infrastructure</strong>
                </h5>
                <ul>
                  <li>
                    GetMagicLink uses a third-party hosting infrastructure
                    in connection with the Services.
                  </li>
                  <li>
                    The provider(s) of the Third-Party Infrastructure make no
                    representation or warranty with respect to such Third-Party
                    Infrastructure.
                  </li>
                  <li>
                    GetMagicLink assumes no liability for any claim that may
                    arise with respect to such Third-Party Infrastructure.
                  </li>
                </ul>
                <br />

                <h5>
                  <strong>Electronic Communications</strong>
                </h5>
                <ul>
                  <li>
                    By using the Service, you agree to receive electronic
                    communications regarding your use of the Service.
                  </li>
                  <li>
                    Any notices, agreements, disclosures or other communications
                    sent electronically will satisfy any legal communication
                    requirements.
                  </li>
                  <li>
                    You may withdraw your consent to receive electronic notices
                    by contacting{" "}
                    <a href="mailto:support@ExponentialHost.com">
                      support@ExponentialHost.com
                    </a>
                  </li>
                </ul>
                <br />

                <h5>
                  <strong>Severability</strong>
                </h5>
                <ul>
                  <li>
                    If any provision of these Terms is invalid, illegal, or
                    incapable of being enforced by any rule of law or public
                    policy, all other provisions of these Terms will remain in
                    full force and effect.
                  </li>
                  <li>
                    The parties will negotiate in good faith to modify these
                    Terms to effect the original intent of the parties if any
                    provision is invalid, illegal, or incapable of being
                    enforced.
                  </li>
                </ul>
                <br />

                <h5>
                  <strong>Force Majeure</strong>
                </h5>
                <ul>
                  <li>
                    GetMagicLink is not responsible for any failure to
                    perform or delay caused by any event beyond its reasonable
                    control, including acts of God, acts of terrorism, civil
                    disturbances, disruption of power or other essential
                    services, interruption or termination of services provided
                    by any service providers used by GetMagicLink, labor
                    disturbances, vandalism, cable cut, computer viruses or
                    other similar occurrences, or any malicious or unlawful acts
                    of any third party.
                  </li>
                </ul>
                <br />
              </section>
              <section>
                <h3>GDPR</h3>
                <p>
                  Under GDPR, Exponential is a data processor. If you need to
                  have Exponential sign a DPA with your company, please contact
                  us at support@GetMagicLink. Data Processing Agreement
                  (DPA) outlines how it processes personal data on behalf of its
                  customers. This DPA is available to customers upon request.
                </p>
              </section>
            </div>
          </CommonPadding>
          </CommonWidth>
        </>
      )}
    </>
  );
};

export default page;
