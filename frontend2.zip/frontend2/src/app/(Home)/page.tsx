"use client";
import UploadVideo from "@/components/UploadVideo/UploadVideo";
import React from "react";
import { styled } from "styled-components";

const Main=styled.div`
  height: 75vh;
  display: flex;
  justify-content: center;
  align-items: center;
`


const page = () => {
  
  return (
      <Main>
        <UploadVideo/>
      </Main>
  );
};

export default page;
