"use client";
import { Card, Container, Text, Grid, Spacer } from "@nextui-org/react";
import styled from "styled-components";
import { useState, useEffect } from "react";
const AboutUsCard = styled(Card)`
  padding: 0px 0px;
`;

const AboutUsDiv = styled.div`
  
`;

const AboutUs = () => {

  const [isready, setIsReady] = useState(false);

  useEffect(() => {
    setIsReady(true);
  }, []);

//TODO: need to change product specific details

  return (
    <>
      {isready && (
        <>
         <head>
          <title>
            VideoCaptionsAI | About Us
          </title>
        </head>
        <AboutUsDiv>
          <Container fluid justify="center" gap={0} css={{marginTop:"20px",width:"90%" ,"@lg":{width:"70%"}}}>
            <Container gap={0}>
              <Grid.Container css={{}}>
                <Grid
                  xs={12}
                  css={{ fd: "column" }}
                  className="AboutCard"
                  justify="flex-start"
                  alignItems="center"
                >
                  <AboutUsCard
                    css={{
                      bgColor: "rgb(224 224 224 / 19%)",
                      
                    }}
                    variant="flat"
                  >
                    <Card.Body css={{ px: "$10", "@md": { px: "$14" } ,overflow:"visible"}}>
                      <Grid xs={12}>
                        <Text h2 weight="extrabold">
                          About Us
                        </Text> 
                      </Grid>
                      <Grid.Container
                        gap={2}
                        css={{ display:"block", "@md": { mt: "$2 !important" },justifyContent:"center",alignItems:"center" ,"@xs":{display:"flex"} }}
                      >
                        <Grid css={{ display: "flex", fd: "column" ,width:"90%"}}>
                          <Text size="$xl" >
                          At GetMagicLink, we're passionate about simplifying the way businesses connect with their customers. With our innovative platform, we empower brands to create mobile wallet cards effortlessly, enhancing engagement and customer experiences. Our team is dedicated to bridging the digital and physical worlds, making it easier than ever for businesses to reach their audience in meaningful ways.
                          </Text>
                          
                          <Spacer y={2} />
                          <Text h3 weight="bold">
                            Our Mission:
                          </Text>
                          <Text size="$xl" >
                          Our mission is to revolutionize customer engagement through mobile wallet technology. We're committed to enabling businesses to effortlessly create and share mobile wallet cards, delivering personalized messages and offers that captivate and delight customers. We believe in the power of seamless digital experiences that connect brands and consumers, ultimately enhancing loyalty and driving success for businesses worldwide.
                          </Text>
                        </Grid>
                        
                      </Grid.Container>
                    </Card.Body>
                  </AboutUsCard>
                </Grid>
              </Grid.Container>
            </Container>
          </Container>
          </AboutUsDiv>
        </>
      )}
    </>
  );
};
export default AboutUs;
