import auth from "./auth";
import nonAuth from "./nonAuth";

export const CreateSrt=async (body:any) =>{
    const config = {
      headers: { "content-type": "multipart/form-data" },
    
    };
    return await nonAuth.post(`/api/process/createsrt`,body,config)
  }
  