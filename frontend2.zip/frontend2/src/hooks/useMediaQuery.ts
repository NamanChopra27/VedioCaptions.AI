import { useLayoutEffect, useState } from 'react';

const useMediaQuery = (query: string): boolean => {
  const [matches, setMatches] = useState(false);

  useLayoutEffect(() => {
    const mediaQuery = window.matchMedia(query);

    const updateMatches = (): void => {
      setMatches(mediaQuery.matches);
    };

    mediaQuery.addListener(updateMatches);
    updateMatches();

    return (): void => {
      mediaQuery.removeListener(updateMatches);
    };
  }, [query]);

  return matches;
};

const useIsMobile = (): boolean => {
  return useMediaQuery('(max-width: 767px)');
};

const useIsTablet = (): boolean => {
  return useMediaQuery('(min-width: 768px) and (max-width: 1023px)');
};

const useIsLaptop = (): boolean => {
  return useMediaQuery('(min-width: 1024px)');
};

export { useIsMobile, useIsTablet, useIsLaptop };
