import { useCallback, useMemo } from 'react';

import { TShowLoginModalData } from '../interfaces/GlobalLoginModal';
import Routes from '../../routes';
import useAppStore from '../store';
import { deleteCookie, getCookie, setCookie } from '../utils/cookieUtil';
import { IUserSlice, TUserData } from '@/store/slice/userSlice';
import { getExpoTokensUsingGoogleOneTap, revalidateToken } from '@/apis/login';
import { useRouter } from 'next/navigation';

export default function useAuth() {
  const router = useRouter();
  const userData: IUserSlice = useAppStore(
    ({ userData }: any) => userData as IUserSlice
  );
  const setUserData = useAppStore(
    ({ setUserData }: any) => setUserData as (data:any) => Promise<any>
  );
  // private methods
  const storeBasicInfo = (data:any) => {
    const {
      id,
      name,
      email,
      picture,
      contact,
      accessToken,
      given_name,
      family_name,
      about,
      roles,
      appProducerHandle,
    } = data;
    setCookie('accessToken', accessToken.id, 90);
    // setCookie('refreshToken', refreshToken.id, 30);
    return setUserData({
      id,
      name,
      email,
      picture,
      contact,
      given_name,
      family_name,
      about,
      roles,
      appProducerHandle,
    });
  };

  // Shared methods/properties
  const authenticate = async () => {
    const c = getCookie('accessToken');
    if (c) {
      // user has cookie
      if (userData.data && userData.data.name) {
        return true;
      } else {
        // user has cookie but no data. Call /revalidateToken
        return revalidateToken(c)
          .then((res: any) => {
            storeBasicInfo(res.userRecord);
            return true
          })
          .catch((e) => {
            return false;
          });
      }
    } else {
      return false;
      // user does not have any cookie. Prompt login
    }
  };

  // Used by google login to get expo tokens
  const storeUserData = async (oneTapData:any) => {
    console.log({ parsedData: oneTapData });
    const { id, name, email, picture } = oneTapData;
    const role = (document.getElementById('userrole') as HTMLInputElement)
      .value;
    const context = (document.getElementById('usercontext') as HTMLInputElement)
      .value;
    const { result } = (await getExpoTokensUsingGoogleOneTap(
      oneTapData,
      role,
      context
    )) as any;
    storeBasicInfo({ ...result, id, name, email, picture });

    // if (result?.roles.includes('PRODUCER')) {
    //   router.pathname === Routes.homePage.path &&
    //     router.push(Routes.apiUsage.path);
    // } else {
    //   router.pathname === Routes.homePage.path &&
    //     router.push(Routes.apis.path);
    // }

  };
  const showLoginModal = useAppStore(
    ({ showLoginModal}: any) => showLoginModal as (data: TShowLoginModalData) => void
  );
  const hideLoginModal = useAppStore(({ hideLoginModal }: any) => hideLoginModal as  () => void
  );

  const isLoggedIn = useMemo(
    () => !!userData.isLoggedIn,
    [userData.isLoggedIn]
  );


  const logout = useCallback(() => {
    deleteCookie('accessToken');
    setUserData(null); // also sets isLogged to false
   // window.google?.accounts.id.disableAutoSelect();
    router.push(Routes.homePage.path);
  }, [userData]);

  const userDetails: TUserData | {} = useMemo(() => {
    return userData.data ? userData.data : {};
  }, [userData.data]);

 // const cancelGLogin = () => window.google?.accounts.id.cancel();



  return {
    isLoggedIn,
    logout,
    userDetails: userDetails as TUserData,
   // cancelGLogin,
    showLoginModal,
    hideLoginModal,
    authenticate,
    storeUserData,
  };
}
