export interface IUserSlice {
  loading: boolean;
  data: {
    id: string;
    name: string;
    email: string;
    picture: string;
    given_name: string;
    family_name: string;
    about: string;
    appProducerHandle: string;
    contact: {
      countryCode: string;
      contactNumber: string;
    };
    roles: Array<any>;
  } | null;
  isLoggedIn: boolean;
}
export type TUserData = IUserSlice['data'];

const UserSlice = (set: (arg0: () => { userData: { loading: boolean; data: any; isLoggedIn: boolean; }; }, arg1: boolean, arg2: string) => void, get: any) => ({
  userData: {
    loading: false,
    data: null,
    isLoggedIn: false,
  } as IUserSlice,
  setUserData: (data: any) => {
    set(
      () => ({
        userData: { loading: false, data, isLoggedIn: !!data },
      }),
      false,
      'SET_USER_DATA'
    );
  },
});

export default UserSlice;
