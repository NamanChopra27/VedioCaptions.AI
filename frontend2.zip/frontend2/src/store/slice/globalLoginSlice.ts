import { CGlobalLoginModal, IGlobalLoginModalData, TShowLoginModalData } from '@/interfaces/GlobalLoginModal';
import { ReactElement, JSXElementConstructor } from 'react';


const globalLoginSlice = (set: (arg0: { (): { globalLoginModal: { id: string | null; headingText: string | ReactElement<any, string | JSXElementConstructor<any>>; loginSuccessCallback?: (() => void) | undefined; loginFailureCallback?: (() => void) | undefined; modalCloseCallback?: (() => void) | undefined; additionalData?: any; visible: boolean; }; }; (): { globalLoginModal: CGlobalLoginModal; }; }, arg1: boolean, arg2: string) => void, get: any) => ({
  globalLoginModal: {
    id: null,
    visible: false,
    headingText: '',
    loginSuccessCallback: null,
    loginFailureCallback: null,
    modalCloseCallback: null,
    additionalData: null,
  } as unknown as IGlobalLoginModalData,

  showLoginModal: (data: TShowLoginModalData) => {
    set(
      () => ({
        globalLoginModal: {
          visible: true,
          ...data,
        },
      }),
      false,
      'SET_LOGIN_MODAL'
    );
  },
  // hideLoginModal: () => {
  //   set(
  //     () => ({
  //       globalLoginModal: new CGlobalLoginModal({ visible: false }),
  //     }),
  //     false,
  //     'HIDE_LOGIN_MODAL'
  //   );
  // },
});

export default globalLoginSlice;
