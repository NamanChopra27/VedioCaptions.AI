import LoadingScreen from '@/components/EmptyStates/LoadingScreen';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import Routes from '../../../routes';


//Can be used to Privatise any route, but here it will redirect to login page if not authenticated
//If no Login page instead using modal, make updates accordingly

export default function PrivateRoute({ children }: { children: React.ReactNode }) {
    const { data: session, status } = useSession();
    const router = useRouter();

    if (status === 'loading') {
        return <LoadingScreen/>;
    }

    if (!session) {
        router.push(Routes.login.path);
        return null;
    }
    if (status === 'authenticated') {
        return <>{children}</>;
    }
}