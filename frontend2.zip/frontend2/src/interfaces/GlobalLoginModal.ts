import { ReactElement } from "react";

export interface IGlobalLoginModalData {
  id: string | null;
  visible: boolean;
  headingText: string | ReactElement;
  loginSuccessCallback?: () => void;
  loginFailureCallback?: () => void;
  modalCloseCallback?: () => void;
  additionalData?: any;
}
type TModalHidden = { visible: false };
export type TShowLoginModalData = Omit<IGlobalLoginModalData, "visible">;
export class CGlobalLoginModal {
  constructor(data: IGlobalLoginModalData | TModalHidden) {
    if (!data.visible) {
      return {
        id: null,
        visible: false,
        headingText: "",
        loginSuccessCallback: null,
        loginFailureCallback: null,
        modalCloseCallback: null,
        additionalData: null,
      };
    }
    return { ...data };
  }
}
