const status = require("http-status");
const {
  getActiveSubscriptionDetails,
  getTrialSubscriptionDetails,
} = require("../models/payment");
module.exports = async (req, res, next) => {
  if (req.context === undefined) {
    // Invalid request
    res.status(401).send("not authenticated");
    return;
  }

  const [activeSubscription, trialSubscription] = await Promise.all([
    getActiveSubscriptionDetails({
      userId: req.context.userId,
    }),
    getTrialSubscriptionDetails({ userId: req.context.userId }),
  ]);

  const details =
    activeSubscription.length > 0 ? activeSubscription : trialSubscription;
  const subscriptionDetails = details && details.length > 0 ? details[0] : null;

  if (subscriptionDetails) {
    req.context.subscriptionDetails = subscriptionDetails;
    req.context.subscription = subscriptionDetails.id;
    req.context.subscriptionStatus = subscriptionDetails.status;
  } else {
    throw {
      code: status.UNAUTHORIZED,
      status: false,
      message: "No active subscription!",
    };
  }

  next();
};
