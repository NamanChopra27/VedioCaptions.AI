const { AWS_ACCESS_ID, AWS_ACCESS_KEY, AWS_BUCKET_NAME } = process.env;

const AWS = require("aws-sdk");
require("aws-sdk/lib/maintenance_mode_message").suppress = true;
const seedrandom = require("seedrandom");
const { v4: uuidv4 } = require("uuid");

const s3 = new AWS.S3({
  accessKeyId: AWS_ACCESS_ID,
  secretAccessKey: AWS_ACCESS_KEY,
});
const bucket = AWS_BUCKET_NAME;

const uploadToS3 = async ({ content, contentType }) => {
  let random = seedrandom(`${new Date().getTime()}`)();
  const keyId = uuidv4(`getmagiclink/${random}`, uuidv4.URL);
  const params = {
    Bucket: bucket,
    Key: `applepass-${keyId}.pkpass`,
    Body: content,
    ContentEncoding: "base64",
    ContentType: contentType,
  };

  const uploadedImage = await s3.upload(params).promise();
  return uploadedImage.Location.replace("s3.amazonaws.com/", "");
};
const uploadImageToS3 = async ({ content, contentType }) => {
  let random = seedrandom(`${new Date().getTime()}`)();
  const keyId = uuidv4(`getmagiclink/${random}`, uuidv4.URL);
  const params = {
    Bucket: bucket,
    Key: `magiclink-${keyId}`,
    Body: content,
    ContentEncoding: "base64",
    ContentType: contentType,
  };

  const uploadedImage = await s3.upload(params).promise();
  return uploadedImage.Location.replace("s3.amazonaws.com/", "");
};

const getFileFromS3 = async (url, isKey = false) => {
  const key = isKey ? url : url.split(`${bucket}/`)[1];
  const params = {
    Bucket: bucket,
    Key: key,
  };
  return new Promise((resolve, reject) => {
    s3.getObject(params, (err, data) => {
      if (err) {
        console.log(err, err.stack);
        reject(err);
      }
      resolve(data.Body.toString());
    });
  }).catch((err) => {
    console.log(err, err.stack);
    throw err;
  });
};

module.exports = {
  uploadToS3,
  uploadImageToS3,
  getFileFromS3,
};
