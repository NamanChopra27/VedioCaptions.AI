const fs = require('fs');
const path = require('path');
const axios = require('axios');
const { AssemblyAI } = require('assemblyai');
const { exec } = require('child_process');
const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');

const API_KEY = 'c8e77c8d314a465d9d533ce363f15519';
const client = new AssemblyAI({ apiKey: API_KEY });


function uploadFile(fileName,prefix) {
    const s3 = new AWS.S3({
      accessKeyId: 'AKIA5IMQH5F6FPU3ZCML',
      secretAccessKey: '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'
    });
  
    const fileContent = fs.readFileSync(fileName);
  
    const params = {
      Bucket: 'testi.exponentialhost.com',
      Key: `${prefix}output.mp4`,
      Body: fileContent
    };
  
    return new Promise((resolve, reject) => {
      s3.upload(params, function(err, data) {
        if (err) {
          console.error('Error uploading file:', err);
          reject(err);
        } else {
          console.log(`File uploaded successfully. ${data.Location}`);
          resolve(data.Location);
        }
      });
    });
};

async function createSRTSubtitles(req, res) {
    const dirPath = path.join(__dirname, "../");
    console.log("function invoked");
  
    try {
      const params = { chars_per_caption: 20 };
      const FILE_URL = req.file.path;
      console.log("https://storage.googleapis.com/aai-web-samples/5_common_sports_injuries.mp3 " + FILE_URL);
      const transcriptData = { audio_url: FILE_URL };
      console.log(transcriptData);
      const uniquePrefix = `${uuidv4()}_`;
  
      let transcript;
      try {
        transcript = await client.transcripts.create(transcriptData, { ...params });
        console.log('Transcript created');
      } catch (error) {
        console.log(error);
      }
  
      if (!transcript || !transcript.id) {
        console.error('Invalid transcript object:', transcript);
        res.status(500).json({
          error: 'Internal Server Error',
          message: 'Invalid transcript object'
        });
        return;
      }
  
      let status = 'queued';
      while (status !== 'completed') {
        const { status: newStatus } = await client.transcripts.get(transcript.id);
        console.log(status)
        status = newStatus;
        if (status === 'completed') {
          console.log('Transcript is completed.');
        } else {
          console.log('Transcript is still processing...');
          await new Promise((resolve) => setTimeout(resolve, 5000));
        }
      }
  
      const srtUrl = `https://api.assemblyai.com/v2/transcript/${transcript.id}/srt?chars_per_caption=20`;
      const srtData = await axios.get(srtUrl, {
        headers: { Authorization: API_KEY },
        timeout: 30000
      });
  
      console.log(__dirname);
      fs.writeFileSync(dirPath +uniquePrefix+ "output.srt", srtData.data);
  
      const command = `ffmpeg -i ${FILE_URL} -vf "subtitles=${dirPath+uniquePrefix}output.srt:force_style='FontName=Verdana,PrimaryColour=&H00FF00&,FontSize=30,Italic=1,MarginV=80'" ${dirPath+uniquePrefix}output.mp4`;
  
      exec(command, async (error, stdout, stderr) => {
        if (error) {
          console.error('FFmpeg Execution Error:', error);
          console.error('FFmpeg stderr:', stderr);
          res.status(500).json({
            error: 'Internal Server Error',
            message: 'Error during FFmpeg execution'
          });
          return;
        }
  
        const fileUrl= await uploadFile(`${dirPath+uniquePrefix}output.mp4`,uniquePrefix);
        console.log(fileUrl);
        fs.unlinkSync(`${dirPath+uniquePrefix}output.srt`);
        fs.unlinkSync(`${dirPath+uniquePrefix}output.mp4`);
        fs.unlinkSync(FILE_URL);
  
        res.json({ url: fileUrl });
        
      });
    } catch (error) {
      console.error('An error occurred:', error);
      res.status(500).json({
        error: 'Internal Server Error',
        message: 'An error occurred during subtitle creation'
      });
    }
}
module.exports={
createSRTSubtitles,
}