module.exports = [
  {
    settings: ["master"],
    host: "videocaptionsai.com", 
    enableGDPRCheck: false,
  },
];
